 <!-- propertyviewing.php -->

<?php
include 'header.php';
// Sample database connection
$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if property ID is provided in the URL
if (isset($_GET['id'])) {
    $propertyId = $_GET['id'];

    // Fetch property details for the selected property
    $propertyDetailsQuery = "SELECT * FROM property WHERE pID = $propertyId";
    $propertyDetailsResult = mysqli_query($dbConnection, $propertyDetailsQuery);

    if ($propertyDetailsResult) {
        if (mysqli_num_rows($propertyDetailsResult) > 0) {
            $property = mysqli_fetch_assoc($propertyDetailsResult);

            // Display property details
            echo '<div class="container">';
            echo '<h2>Property Details</h2>';
            echo '<table class="property-table">';
            echo '<thead><tr><th colspan="2">Property Details</th></tr></thead>';
            echo '<tbody>';
            echo '<tr>';
            echo '<td colspan="2"><img src="' . $property['pImage'] . '" alt="Property Image" class="property-image"></td>';
            echo '</tr>';
            echo '<tr>';
            echo '<td class="bold-text">Type:</td>';
            echo '<td>' . (isset($property['pType']) ? $property['pType'] : '') . '</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<td class="bold-text">Area:</td>';
            echo '<td>' . (isset($property['pArea']) ? $property['pArea'] : '') . '</td>';
            echo '</tr>';
            echo '<tr>';
            echo '<td class="bold-text">Featured:</td>';
            echo '<td>' . (isset($property['pFeatured']) ? $property['pFeatured'] : '') . '</td>';
            echo '</tr>';
            // Add other property details as needed
            // ...

            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        } else {
            echo '<p>Property not found.</p>';
        }
    } else {
        echo '<p>Error executing query: ' . mysqli_error($dbConnection) . '</p>';
    }
} else {
    echo '<p>Invalid property ID.</p>';
}

mysqli_close($dbConnection);
?>