 <?php
session_start();

if (!isset($_SESSION['broker_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Your database connection code here...
$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $propertyIdToDelete = mysqli_real_escape_string($dbConnection, $_GET['id']);
    
    // Check if the property belongs to the current broker
    $brokerId = $_SESSION['broker_id'];
    $checkPropertyOwnership = "SELECT * FROM property WHERE bId = $brokerId AND pID = $propertyIdToDelete";
    $checkResult = mysqli_query($dbConnection, $checkPropertyOwnership);

    if ($checkResult && mysqli_num_rows($checkResult) > 0) {
        // Delete the property
        $deletePropertyQuery = "DELETE FROM property WHERE pID = $propertyIdToDelete";
        if (mysqli_query($dbConnection, $deletePropertyQuery)) {
            // Also delete from the 'own' table
            $deleteFromOwnQuery = "DELETE FROM own WHERE pID = $propertyIdToDelete";
            mysqli_query($dbConnection, $deleteFromOwnQuery);

            echo '<script>alert("Property deleted successfully.");</script>';
            header("Location: mylistings.php");
            exit();
        } else {
            echo "Error deleting property: " . mysqli_error($dbConnection);
        }
    } else {
        echo "You do not have permission to delete this property.";
    }
}

mysqli_close($dbConnection);
?>