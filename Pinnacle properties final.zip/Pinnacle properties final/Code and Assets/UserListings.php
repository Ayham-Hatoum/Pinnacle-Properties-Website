 <?php
include 'header.php';
// Your database connection code here...
$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if bId is provided in the query string
if (isset($_GET['bId']) && !empty($_GET['bId'])) {
    $bId = mysqli_real_escape_string($dbConnection, $_GET['bId']);

    // Fetch user information
    $fetchUserQuery = "SELECT bFirstName, bLastName FROM broker WHERE bId = '$bId'";
    $userResult = mysqli_query($dbConnection, $fetchUserQuery);

    if ($userResult && mysqli_num_rows($userResult) > 0) {
        $user = mysqli_fetch_assoc($userResult);
        $userFullName = $user['bFirstName'] . ' ' . $user['bLastName'];
    } else {
        // Handle case where user is not found
        echo '<script>alert("User not found."); window.location.href = "Users.php";</script>';
        exit();
    }

    // Fetch user's listings
    $fetchListingsQuery = "SELECT * FROM property WHERE bId = '$bId'";
    $listingsResult = mysqli_query($dbConnection, $fetchListingsQuery);
}

// Check if form is submitted to delete or feature a property
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['deleteProperty'])) {
        $pIdToDelete = mysqli_real_escape_string($dbConnection, $_POST['deleteProperty']);

        // Fetch sId from own table
        $fetchSellerIdQuery = "SELECT sId FROM own WHERE pId = '$pIdToDelete'";
        $sellerIdResult = mysqli_query($dbConnection, $fetchSellerIdQuery);

        if ($sellerIdResult && mysqli_num_rows($sellerIdResult) > 0) {
            $sellerId = mysqli_fetch_assoc($sellerIdResult)['sId'];

            // Delete property from property table
            $deletePropertyQuery = "DELETE FROM property WHERE pId = '$pIdToDelete'";
            mysqli_query($dbConnection, $deletePropertyQuery);

            // Delete property from own table
            $deleteOwnQuery = "DELETE FROM own WHERE pId = '$pIdToDelete'";
            mysqli_query($dbConnection, $deleteOwnQuery);

            // Delete seller from own table
            $deleteSellerQuery = "DELETE FROM own WHERE sId = '$sellerId'";
            mysqli_query($dbConnection, $deleteSellerQuery);
        }
    } elseif (isset($_POST['featureProperty'])) {
        $pIdToFeature = mysqli_real_escape_string($dbConnection, $_POST['featureProperty']);

        // Update property's featured status
        $featurePropertyQuery = "UPDATE property SET pFeatured = 'Yes' WHERE pId = '$pIdToFeature'";
        mysqli_query($dbConnection, $featurePropertyQuery);
    } elseif (isset($_POST['unfeatureProperty'])) {
        $pIdToUnfeature = mysqli_real_escape_string($dbConnection, $_POST['unfeatureProperty']);

        // Update property's featured status to No
        $unfeaturePropertyQuery = "UPDATE property SET pFeatured = 'No' WHERE pId = '$pIdToUnfeature'";
        mysqli_query($dbConnection, $unfeaturePropertyQuery);
    }
}

?>

<!-- Rest of the code remains unchanged -->


<!-- HTML for displaying user's listings -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $userFullName; ?>'s Listings</title>
    <style>
        <?php include 'styles.css'; ?> /* Include external CSS file for styling */
        
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #333;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: auto;
            text-align: center;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

       
		.delete-btn, .feature-btn {
    background-color: #ff6666;
            color: white;
            border: yes;
            cursor: pointer;
			margin-right: 15px;
}
.button-container {
    display: flex;
}

    </style>
</head>
<body>

    <!-- Include header.php file for the header -->

    <div class="container">
        <h2><?php echo $userFullName; ?>'s Listings</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Type</th>
                <th>Price</th>
                <th>Area</th>
                <th>Featured</th>
                <th>Image</th>
                <th>Date</th>
                <th>Governate</th>
                <th>Location</th>
                <th>Action</th>
            </tr>
            <?php
              while ($listingResult = mysqli_fetch_assoc($listingsResult)) {
            echo "<tr>";
            echo "<td>{$listingResult['pId']}</td>";
            echo "<td>{$listingResult['pName']}</td>";
            echo "<td>{$listingResult['pDesc']}</td>";
            echo "<td>{$listingResult['pType']}</td>";
            echo "<td>{$listingResult['pPrice']}</td>";
            echo "<td>{$listingResult['pArea']}</td>"; // Display Area column
            echo "<td>{$listingResult['pFeatured']}</td>"; // Display Featured column
            echo "<td>{$listingResult['pImage']}</td>";
            echo "<td>{$listingResult['oDate']}</td>";
            echo "<td>{$listingResult['pGovernate']}</td>";
            echo "<td>{$listingResult['pLocation']}</td>";
            echo "<td>";
            echo "<div class='button-container'>";
                echo "<button class='delete-btn' onclick=\"deleteProperty({$listingResult['pId']}, {$listingResult['bId']})\">Delete</button>";
                if ($listingResult['pFeatured'] == 'Yes') {
                    echo "<button class='unfeature-btn' onclick=\"unfeatureProperty({$listingResult['pId']}, {$listingResult['bId']})\">Unfeature</button>";
                } else {
                    echo "<button class='feature-btn' onclick=\"featureProperty({$listingResult['pId']}, {$listingResult['bId']})\">Feature</button>";
                }
                echo "</div>";
                echo "</td>";

                echo "</tr>";
            }
        ?>

    </table>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script>
            function deleteProperty(pId, bId) {
                if (confirm('Are you sure you want to delete this property?')) {
                    $.ajax({
                        type: 'POST',
                        url: 'UserListings.php?bId=' + bId,
                        data: {
                            'deleteProperty': pId,
                            'bId': bId
                        },
                        success: function () {
                            location.reload(); // Reload the page after successful deletion
                        }
                    });
                }
            }

            function featureProperty(pId, bId) {
                if (confirm('Are you sure you want to feature this property?')) {
                    $.ajax({
                        type: 'POST',
                        url: 'UserListings.php?bId=' + bId,
                        data: {
                            'featureProperty': pId,
                            'bId': bId
                        },
                        success: function () {
                            location.reload(); // Reload the page after successful feature
                        }
                    });
                }
            }

            function unfeatureProperty(pId, bId) {
                if (confirm('Are you sure you want to unfeature this property?')) {
                    $.ajax({
                        type: 'POST',
                        url: 'UserListings.php?bId=' + bId,
                        data: {
                            'unfeatureProperty': pId,
                            'bId': bId
                        },
                        success: function () {
                            location.reload(); // Reload the page after successful unfeature
                        }
                    });
                }
            }
        </script>

    </div>

</body>
</html