 <?php
	include 'header.php' ;

if (!isset($_SESSION['broker_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Your database connection code here...
$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

$brokerId = $_SESSION['broker_id'];

// Fetch properties created by the broker
$sql = "SELECT pID, pName, pType, pDesc, pPrice, pGovernate, pLocation, pImage FROM property WHERE bId = $brokerId";
$result = mysqli_query($dbConnection, $sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Listings</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            overflow: auto;
            animation: fadeIn 1s ease-out;
        }

        h1 {
            color: #4caf50;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2em;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
        }

        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
            width: 80%;
            text-align: center;
            margin: 20px 0;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4caf50;
            color: white;
            font-weight: bold;
        }

        td img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 5px;
        }

        .button-container {
            display: flex;
            justify-content: space-around;
        }

        .update-button, .delete-button {
            padding: 8px 16px;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
            cursor: pointer;
        }

        .update-button {
            background-color: #4caf50;
        }

        .delete-button {
            background-color: #f44336;
        }

        .update-button:hover, .delete-button:hover {
            opacity: 0.8;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<!-- Display properties in a table -->
<div class="form-section">
    <h1>My Listings</h1>
    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        echo '<table>';
        echo '<thead><tr>';
        echo '<th>Name</th>';
        echo '<th>Type</th>';
        echo '<th>Description</th>';
        echo '<th>Price</th>';
        echo '<th>Governate</th>';
        echo '<th>Location</th>';
        echo '<th>Image</th>';
        echo '<th>Action</th>';
        echo '</tr></thead>';
        echo '<tbody>';

        while ($property = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $property['pName'] . '</td>';
            echo '<td>' . $property['pType'] . '</td>';
            echo '<td>' . $property['pDesc'] . '</td>';
            echo '<td>$' . $property['pPrice'] . '</td>';
            echo '<td>' . $property['pGovernate'] . '</td>';
            echo '<td>' . $property['pLocation'] . '</td>';
            echo '<td><img src="' . $property['pImage'] . '" alt="property"/></td>';
            echo '<td class="button-container">';
            echo '<a class="update-button" href="propertyedit.php?id=' . $property['pID'] . '">Update</a>';
            echo '<a class="delete-button" href="javascript:void(0);" onclick="confirmDelete(' . $property['pID'] . ');">Delete</a>';
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No listings found.</p>';
    }

    mysqli_close($dbConnection);
    ?>
</div>
<script>
    function confirmDelete(propertyId) {
        var confirmDelete = confirm("Are you sure you want to delete this property?");
        if (confirmDelete) {
            window.location.href = 'propertydelete.php?id=' + propertyId;
        }
    }
</script>
<?php
// Display alert message if set in session
if (isset($_SESSION['alert_message'])) {
    echo '<script>alert("' . $_SESSION['alert_message'] . '");</script>';
    // Clear the session variable
    unset($_SESSION['alert_message']);
}
?>
</body>
</html