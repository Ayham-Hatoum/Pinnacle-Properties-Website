 <?php
// Include the header
include 'header.php';
$bId = $_SESSION['broker_id'];

// Sample database connection
$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

$propertyId = 0;
$property = [];

// Get the property ID from the URL
if (isset($_GET['id'])) {
    $propertyId = $_GET['id'];

    // Fetch property details based on the property ID
    $propertyDetailsQuery = "SELECT * FROM property WHERE pID = ?";
    $stmt = mysqli_prepare($dbConnection, $propertyDetailsQuery);
    mysqli_stmt_bind_param($stmt, "i", $propertyId);
    mysqli_stmt_execute($stmt);
    $propertyDetailsResult = mysqli_stmt_get_result($stmt);

    if ($propertyDetailsResult && mysqli_num_rows($propertyDetailsResult) > 0) {
        $property = mysqli_fetch_assoc($propertyDetailsResult);

        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Continue with processing the form data
            $pName = mysqli_real_escape_string($dbConnection, $_POST['pName']);
            $pDesc = mysqli_real_escape_string($dbConnection, $_POST['pDesc']);
            $pType = mysqli_real_escape_string($dbConnection, $_POST['pType']);
            $pGovernate = $_POST['pGovernate'];
            $pLocation = mysqli_real_escape_string($dbConnection, $_POST['pLocation']);
            $pPrice = mysqli_real_escape_string($dbConnection, $_POST['pPrice']);
            $pArea = mysqli_real_escape_string($dbConnection, $_POST['pArea']);
            $pSoldOut = mysqli_real_escape_string($dbConnection, $_POST['pSoldOut']);

            // Update the property details in the database
            $updatePropertyQuery = "UPDATE property SET pName=?, pDesc=?, pType=?, pGovernate=?, pLocation=?, pPrice=?, pArea=?, pSoldOut=?, pSoldOutDate=? WHERE pID=?";
            $stmtUpdate = mysqli_prepare($dbConnection, $updatePropertyQuery);
			$soldOutDate = null;
if ($pSoldOut === 'Yes') {
    // If property is marked as sold out, set the sold-out date to current time plus seven days
    $soldOutDate = date('Y-m-d H:i:s', strtotime('+7 days'));
}
mysqli_stmt_bind_param($stmtUpdate, "sssssssssi", $pName, $pDesc, $pType, $pGovernate, $pLocation, $pPrice, $pArea, $pSoldOut, $soldOutDate, $propertyId);

            if (mysqli_stmt_execute($stmtUpdate)) {
                // Property details updated successfully

                // Update the own entity with the new seller ID
                $newSellerId = mysqli_real_escape_string($dbConnection, $_POST['new_seller']);

                $updateOwnQuery = "UPDATE own SET sId = ? WHERE pId = ?";
                $updateOwnStmt = mysqli_prepare($dbConnection, $updateOwnQuery);
                mysqli_stmt_bind_param($updateOwnStmt, "ii", $newSellerId, $propertyId);
                mysqli_stmt_execute($updateOwnStmt);
                mysqli_stmt_close($updateOwnStmt);

                // Handle image update
                if (!empty($_FILES["pImage"]["name"])) {
                    // Delete the existing image
                    if (file_exists($property['pImage'])) {
                        unlink($property['pImage']);
                    }

                    // Upload the new image
                    $targetDir = "PropertyImage/broker_$bId/";
                    if (!is_dir($targetDir)) {
                        mkdir($targetDir, 0777, true);
                    }
                    $uploadedFiles = [];

                    if (is_array($_FILES["pImage"]["name"])) {
                        $fileCount = count($_FILES["pImage"]["name"]);

                        for ($i = 0; $i < $fileCount; $i++) {
                            $targetFile = $targetDir . basename($_FILES["pImage"]["name"][$i]);
                            move_uploaded_file($_FILES["pImage"]["tmp_name"][$i], $targetFile);
                            $uploadedFiles[] = $targetFile;
                        }
                    } else {
                        $targetFile = $targetDir . basename($_FILES["pImage"]["name"]);
                        move_uploaded_file($_FILES["pImage"]["tmp_name"], $targetFile);
                        $uploadedFiles[] = $targetFile;
                    }

                    // Convert array of uploaded files to a string for database storage
                    $imageString = implode(",", $uploadedFiles);

                    // Update the image path in the database
                    $updateImageQuery = "UPDATE property SET pImage = ? WHERE pID = ?";
                    $stmtImage = mysqli_prepare($dbConnection, $updateImageQuery);
                    mysqli_stmt_bind_param($stmtImage, "si", $imageString, $propertyId);
                    mysqli_stmt_execute($stmtImage);
                    mysqli_stmt_close($stmtImage);
                }

                echo '<script>alert("Property details updated successfully");</script>';
                echo '<script>window.location.href = "index.php";</script>';
                exit();
            } else {
                // Error updating property details
                echo '<script>alert("Error updating property details");</script>';
            }

            // Close the statement
            mysqli_stmt_close($stmtUpdate);
        }
    } else {
        echo '<p>Error: Property ID not found</p>';
    }
} else {
    echo '<p>Invalid request</p>';
}

// Continue with the rest of the code
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Property</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        h2 {
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            text-indent: 1px;
            text-overflow: '';
            background-color: #fff;
            background-image: url('data:image/svg+xml;utf8,<svg fill="#555" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z" /></svg>');
            background-repeat: no-repeat;
            background-position-x: 100%;
            background-position-y: 5px;
        }

        input[type="file"] {
            display: none;
        }

        .image-container {
            position: relative;
            margin-bottom: 20px;
        }

        .image-container img {
            max-width: 100%;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }

        .update-image-button {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background-color: #3498db;
            color: #fff;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .update-image-button:hover {
            background-color: #2980b9;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- Your HTML content here -->
    <form action="propertyedit.php?id=<?php echo $propertyId; ?>" method="post" enctype="multipart/form-data">
        <h2>Edit Property</h2>
        <input type="hidden" name="id" value="<?php echo $propertyId; ?>">

        <label for="pName">Property Name:</label>
        <input type="text" id="pName" name="pName" value="<?php echo isset($property['pName']) ? $property['pName'] : ''; ?>" required>

        <label for="pDesc">Description:</label>
        <textarea id="pDesc" name="pDesc" required><?php echo isset($property['pDesc']) ? $property['pDesc'] : ''; ?></textarea>

        <label for="pType">Property Type:</label>
        <select id="pType" name="pType" required>
            <option value="">Property Type</option>
            <option value="Apartment for sale" <?php echo isset($property['pType']) && $property['pType'] === 'Apartment for sale' ? 'selected' : ''; ?>>Apartment for sale</option>
            <option value="Apartment for rent" <?php echo isset($property['pType']) && $property['pType'] === 'Apartment for rent' ? 'selected' : ''; ?>>Apartment for rent</option>
            <option value="Building for sale" <?php echo isset($property['pType']) && $property['pType'] === 'Building for sale' ? 'selected' : ''; ?>>Building for sale</option>
            <option value="Land for sale" <?php echo isset($property['pType']) && $property['pType'] === 'Land for sale' ? 'selected' : ''; ?>>Land for sale</option>
        </select>

        <label for="pGovernate">Governate:</label>
        <select id="pGovernate" name="pGovernate" required>
            <option value="">Select Governate</option>
            <option value="Beirut" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Beirut' ? 'selected' : ''; ?>>Beirut</option>
            <option value="Mount Lebanon" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Mount Lebanon' ? 'selected' : ''; ?>>Mount Lebanon</option>
            <option value="Akkar" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Akkar' ? 'selected' : ''; ?>>Akkar</option>
            <option value="Baalbek-Hermel" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Baalbek-Hermel' ? 'selected' : ''; ?>>Baalbek-Hermel</option>
            <option value="Beqaa" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Beqaa' ? 'selected' : ''; ?>>Beqaa</option>
            <option value="Keserwan-Jbeil" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Keserwan-Jbeil' ? 'selected' : ''; ?>>Keserwan-Jbeil</option>
            <option value="Nabatieh" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'Nabatieh' ? 'selected' : ''; ?>>Nabatieh</option>
            <option value="North" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'North' ? 'selected' : ''; ?>>North</option>
            <option value="South" <?php echo isset($property['pGovernate']) && $property['pGovernate'] === 'South' ? 'selected' : ''; ?>>South</option>
        </select>

        <label for="pLocation">Location:</label>
        <input type="text" id="pLocation" name="pLocation" value="<?php echo isset($property['pLocation']) ? $property['pLocation'] : ''; ?>" required>

        <label for="pPrice">Price:</label>
        <input type="text" id="pPrice" name="pPrice" value="<?php echo isset($property['pPrice']) ? $property['pPrice'] : ''; ?>" required>

        <label for="pArea">Area:</label>
        <input type="text" id="pArea" name="pArea" value="<?php echo isset($property['pArea']) ? $property['pArea'] : ''; ?>" required>

        <label for="pSoldOut">Sold Out:</label>
        <select id="pSoldOut" name="pSoldOut" required>
            <option value="No" <?php echo isset($property['pSoldOut']) && $property['pSoldOut'] === 'No' ? 'selected' : ''; ?>>No</option>
            <option value="Yes" <?php echo isset($property['pSoldOut']) && $property['pSoldOut'] === 'Yes' ? 'selected' : ''; ?>>Yes</option>
        </select>
<label for="seller_id">Select Seller or <a href="Sellercreate3.php?pid=<?php echo $propertyId; ?>">Create New Seller</a>:</label>
<select name="new_seller" required>
    <?php
    // Fetch current seller based on the pId in the own entity
    $ownInfoQuery = "SELECT own.sId
                     FROM own 
                     WHERE own.pId = ?";
    $ownStmt = mysqli_prepare($dbConnection, $ownInfoQuery);
    mysqli_stmt_bind_param($ownStmt, "i", $propertyId);
    mysqli_stmt_execute($ownStmt);
    $ownInfoResult = mysqli_stmt_get_result($ownStmt);

    $currentSellerId = null;

    if ($ownInfoResult && mysqli_num_rows($ownInfoResult) > 0) {
        $ownInfo = mysqli_fetch_assoc($ownInfoResult);
        $currentSellerId = $ownInfo['sId'];

        // Display the current seller as the default option
        $sellerInfoQuery = "SELECT sId, CONCAT(sId, ' - ', sFirstName, ' ', sLastName) AS sellerName
                            FROM seller
                            WHERE sId = ?";
        $sellerStmt = mysqli_prepare($dbConnection, $sellerInfoQuery);
        mysqli_stmt_bind_param($sellerStmt, "i", $currentSellerId);
        mysqli_stmt_execute($sellerStmt);
        $sellerInfoResult = mysqli_stmt_get_result($sellerStmt);

        if ($sellerInfoResult && mysqli_num_rows($sellerInfoResult) > 0) {
            $sellerInfo = mysqli_fetch_assoc($sellerInfoResult);
            echo '<option value="' . $sellerInfo['sId'] . '" selected>' . $sellerInfo['sellerName'] . '</option>';
        }
        mysqli_stmt_close($sellerStmt);
    }
    mysqli_stmt_close($ownStmt);

    // Fetch other sellers created by the same broker
    $availableSellersQuery = "SELECT sId, CONCAT(sId, ' - ', sFirstName, ' ', sLastName) AS sellerName
                              FROM seller
                              WHERE bId = ? AND sId != ?";
    $availableSellersStmt = mysqli_prepare($dbConnection, $availableSellersQuery);
    mysqli_stmt_bind_param($availableSellersStmt, "ii", $bId, $currentSellerId);
    mysqli_stmt_execute($availableSellersStmt);
    $availableSellersResult = mysqli_stmt_get_result($availableSellersStmt);

    if ($availableSellersResult && mysqli_num_rows($availableSellersResult) > 0) {
        while ($seller = mysqli_fetch_assoc($availableSellersResult)) {
            // Display other available sellers
            echo '<option value="' . $seller['sId'] . '">' . $seller['sellerName'] . '</option>';
        }
    }
    mysqli_stmt_close($availableSellersStmt);
    ?>
</select>



        <!-- Add the image input field -->
        <label for="pImage">Image:</label>
        <div class="image-container">
            <img src="<?php echo isset($property['pImage']) ? $property['pImage'] : ''; ?>" alt="Property Image">
            <input type="file" id="pImage" name="pImage">
        </div>

        <input type="submit" value="Update Property">
    </form>

    <!-- Include the footer -->
    <?php include 'footer.php'; ?>

    <!-- Close the database connection -->
    <?php mysqli_close($dbConnection); ?>
</body>
</html>