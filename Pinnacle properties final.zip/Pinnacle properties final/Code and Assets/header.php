 <!DOCTYPE html>
<html lang="en">
<?php session_start(); 
?>

<head>
<style>


@-webkit-keyframes animate-svg-fill-1 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 147, 107);
  }
}

@keyframes animate-svg-fill-1 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 147, 107);
  }
}

.svg-1 {
  -webkit-animation: animate-svg-fill-1 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 0.8s both;
          animation: animate-svg-fill-1 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 0.8s both;
}

@-webkit-keyframes animate-svg-fill-2 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(242, 246, 252);
  }
}

@keyframes animate-svg-fill-2 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(242, 246, 252);
  }
}

.svg-2 {
  -webkit-animation: animate-svg-fill-2 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1s both;
          animation: animate-svg-fill-2 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1s both;
}

@-webkit-keyframes animate-svg-fill-3 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

@keyframes animate-svg-fill-3 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

.svg-3 {
  -webkit-animation: animate-svg-fill-3 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.2000000000000002s both;
          animation: animate-svg-fill-3 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.2000000000000002s both;
}

@-webkit-keyframes animate-svg-fill-4 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(233, 237, 245);
  }
}

@keyframes animate-svg-fill-4 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(233, 237, 245);
  }
}

.svg-4 {
  -webkit-animation: animate-svg-fill-4 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.4000000000000001s both;
          animation: animate-svg-fill-4 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.4000000000000001s both;
}

@-webkit-keyframes animate-svg-fill-5 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

@keyframes animate-svg-fill-5 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

.svg-5 {
  -webkit-animation: animate-svg-fill-5 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.6s both;
          animation: animate-svg-fill-5 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.6s both;
}

@-webkit-keyframes animate-svg-fill-6 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(233, 237, 245);
  }
}

@keyframes animate-svg-fill-6 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(233, 237, 245);
  }
}

.svg-6 {
  -webkit-animation: animate-svg-fill-6 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.8s both;
          animation: animate-svg-fill-6 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 1.8s both;
}

@-webkit-keyframes animate-svg-fill-7 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(156, 156, 156);
  }
}

@keyframes animate-svg-fill-7 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(156, 156, 156);
  }
}

.svg-7 {
  -webkit-animation: animate-svg-fill-7 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2s both;
          animation: animate-svg-fill-7 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2s both;
}

@-webkit-keyframes animate-svg-fill-8 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(210, 235, 90);
  }
}

@keyframes animate-svg-fill-8 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(210, 235, 90);
  }
}

.svg-8 {
  -webkit-animation: animate-svg-fill-8 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.2s both;
          animation: animate-svg-fill-8 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.2s both;
}

@-webkit-keyframes animate-svg-fill-9 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

@keyframes animate-svg-fill-9 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

.svg-9 {
  -webkit-animation: animate-svg-fill-9 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.4000000000000004s both;
          animation: animate-svg-fill-9 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.4000000000000004s both;
}

@-webkit-keyframes animate-svg-fill-10 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(180, 210, 65);
  }
}

@keyframes animate-svg-fill-10 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(180, 210, 65);
  }
}

.svg-10 {
  -webkit-animation: animate-svg-fill-10 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.6s both;
          animation: animate-svg-fill-10 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.6s both;
}

@-webkit-keyframes animate-svg-fill-11 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(74, 152, 247);
  }
}

@keyframes animate-svg-fill-11 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(74, 152, 247);
  }
}

.svg-11 {
  -webkit-animation: animate-svg-fill-11 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.8s both;
          animation: animate-svg-fill-11 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 2.8s both;
}

@-webkit-keyframes animate-svg-fill-12 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

@keyframes animate-svg-fill-12 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

.svg-12 {
  -webkit-animation: animate-svg-fill-12 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3s both;
          animation: animate-svg-fill-12 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3s both;
}

@-webkit-keyframes animate-svg-fill-13 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(74, 152, 247);
  }
}

@keyframes animate-svg-fill-13 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(74, 152, 247);
  }
}

.svg-13 {
  -webkit-animation: animate-svg-fill-13 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.2s both;
          animation: animate-svg-fill-13 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.2s both;
}

@-webkit-keyframes animate-svg-fill-14 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

@keyframes animate-svg-fill-14 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

.svg-14 {
  -webkit-animation: animate-svg-fill-14 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.4000000000000004s both;
          animation: animate-svg-fill-14 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.4000000000000004s both;
}

@-webkit-keyframes animate-svg-fill-15 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

@keyframes animate-svg-fill-15 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

.svg-15 {
  -webkit-animation: animate-svg-fill-15 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.6000000000000005s both;
          animation: animate-svg-fill-15 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.6000000000000005s both;
}

@-webkit-keyframes animate-svg-fill-16 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(178, 135, 109);
  }
}

@keyframes animate-svg-fill-16 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(178, 135, 109);
  }
}

.svg-16 {
  -webkit-animation: animate-svg-fill-16 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.8s both;
          animation: animate-svg-fill-16 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 3.8s both;
}

@-webkit-keyframes animate-svg-fill-17 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(150, 104, 87);
  }
}

@keyframes animate-svg-fill-17 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(150, 104, 87);
  }
}

.svg-17 {
  -webkit-animation: animate-svg-fill-17 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4s both;
          animation: animate-svg-fill-17 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4s both;
}

@-webkit-keyframes animate-svg-fill-18 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(178, 135, 109);
  }
}

@keyframes animate-svg-fill-18 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(178, 135, 109);
  }
}

.svg-18 {
  -webkit-animation: animate-svg-fill-18 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.2s both;
          animation: animate-svg-fill-18 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.2s both;
}

@-webkit-keyframes animate-svg-fill-19 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(163, 212, 255);
  }
}

@keyframes animate-svg-fill-19 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(163, 212, 255);
  }
}

.svg-19 {
  -webkit-animation: animate-svg-fill-19 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.4s both;
          animation: animate-svg-fill-19 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.4s both;
}

@-webkit-keyframes animate-svg-fill-20 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

@keyframes animate-svg-fill-20 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(101, 177, 252);
  }
}

.svg-20 {
  -webkit-animation: animate-svg-fill-20 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.6000000000000005s both;
          animation: animate-svg-fill-20 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.6000000000000005s both;
}

@-webkit-keyframes animate-svg-fill-21 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(247, 247, 247);
  }
}

@keyframes animate-svg-fill-21 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(247, 247, 247);
  }
}

.svg-21 {
  -webkit-animation: animate-svg-fill-21 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.8s both;
          animation: animate-svg-fill-21 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 4.8s both;
}

@-webkit-keyframes animate-svg-fill-22 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

@keyframes animate-svg-fill-22 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(207, 207, 207);
  }
}

.svg-22 {
  -webkit-animation: animate-svg-fill-22 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5s both;
          animation: animate-svg-fill-22 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5s both;
}

@-webkit-keyframes animate-svg-fill-23 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 147, 107);
  }
}

@keyframes animate-svg-fill-23 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 147, 107);
  }
}

.svg-23 {
  -webkit-animation: animate-svg-fill-23 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.2s both;
          animation: animate-svg-fill-23 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.2s both;
}

@-webkit-keyframes animate-svg-fill-24 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

@keyframes animate-svg-fill-24 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(255, 112, 69);
  }
}

.svg-24 {
  -webkit-animation: animate-svg-fill-24 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.4s both;
          animation: animate-svg-fill-24 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.4s both;
}

@-webkit-keyframes animate-svg-fill-25 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

@keyframes animate-svg-fill-25 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

.svg-25 {
  -webkit-animation: animate-svg-fill-25 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.6000000000000005s both;
          animation: animate-svg-fill-25 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.6000000000000005s both;
}

@-webkit-keyframes animate-svg-fill-26 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

@keyframes animate-svg-fill-26 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

.svg-26 {
  -webkit-animation: animate-svg-fill-26 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.8s both;
          animation: animate-svg-fill-26 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 5.8s both;
}

@-webkit-keyframes animate-svg-fill-27 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

@keyframes animate-svg-fill-27 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

.svg-27 {
  -webkit-animation: animate-svg-fill-27 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 6s both;
          animation: animate-svg-fill-27 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 6s both;
}

@-webkit-keyframes animate-svg-fill-28 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

@keyframes animate-svg-fill-28 {
  0% {
    fill: transparent;
  }

  100% {
    fill: rgb(0, 0, 0);
  }
}

.svg-28 {
  -webkit-animation: animate-svg-fill-28 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 6.2s both;
          animation: animate-svg-fill-28 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55) 6.2s both;
}


.pinnacle-link {
    display: flex;
    align-items: center;
    text-decoration: none;
  
}

.pinnacle-text {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
    margin-left: -40px; /* Adjust the left margin as needed */
    color: #FF5733; /* Set the text color */
  
}

.pinnacle-link:hover {
    text-decoration: none; /* Remove underline on hover */
}

.pinnacle-link:hover .pinnacle-text {
    color: #FF5733; /* Change the color on hover */
  

</style>
    <title> Real Estate</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/style.css" />
    <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.js"></script>
    <script src="assets/script.js"></script>

    <!-- Owl stylesheet -->
    <link rel="stylesheet" href="assets/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="assets/owl-carousel/owl.theme.css">
    <script src="assets/owl-carousel/owl.carousel.js"></script>
    <!-- Owl stylesheet -->

    <!-- slitslider -->
    <link rel="stylesheet" type="text/css" href="assets/slitslider/css/style.css" />
    <link rel="stylesheet" type="text/css" href="assets/slitslider/css/custom.css" />
    <script type="text/javascript" src="assets/slitslider/js/modernizr.custom.79639.js"></script>
    <script type="text/javascript" src="assets/slitslider/js/jquery.ba-cond.min.js"></script>
    <script type="text/javascript" src="assets/slitslider/js/jquery.slitslider.js"></script>
    <!-- slitslider -->

</head>

<body>

    <!-- Header Starts -->
    <div class="navbar-wrapper">

        <div class="navbar-inverse" role="navigation">
            <div class="container">
                <div class="navbar-header">

                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                </div>

                <!-- Nav Starts -->
                <div class="navbar-collapse  collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                       

                        <li><a href="contact.php">Support</a></li>
                        <?php if (isset($_SESSION['broker_id'])) : ?>
                            <?php
    // Sample database connection
    $dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");

    if (!$dbConnection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the user is logged in
   
        $brokerId = $_SESSION['broker_id'];

        // Fetch broker information, including profile picture
        $sql = "SELECT bPic FROM broker WHERE bId = $brokerId";
        $result = mysqli_query($dbConnection, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
    $brokerData = mysqli_fetch_assoc($result);

    // Check if the user has a profile picture
    $profilePicture = !empty($brokerData['bPic']) ? $brokerData['bPic'] : 'images/default.png';

    // Display profile picture as an icon with a link to profile.php
    echo '<a href="profile.php">';
    echo '<img src="' . $profilePicture . '" alt="Profile Picture" style="width: 40px; height: 40px; border-radius: 50%;">';
    echo '</a>';
}
    
  // Check if the user is logged in
    if (isset($_SESSION['broker_id'])) {
        $brokerId = $_SESSION['broker_id'];

        // Fetch broker information, including role
        $checkRoleQuery = "SELECT bRole FROM broker WHERE bId = '$brokerId'";
        $roleResult = mysqli_query($dbConnection, $checkRoleQuery);

        if ($roleResult) {
            if (mysqli_num_rows($roleResult) > 0) {
                $brokerRole = mysqli_fetch_assoc($roleResult)['bRole'];

                if ($brokerRole == 3) {
                   echo  '<li><a href="Users.php">Users</a></li>';
                } else {
                    $usersLink = ''; // Empty string if not bRole 3
                }
            } else {
                // Handle the case where the result is empty
                $usersLink = '';
            }
        } else {
            // Handle the case where the query fails
            $usersLink = '';
        }
    } else {
        // Handle the case where the user is not logged in
        $usersLink = '';
    }
    mysqli_close($dbConnection);
    ?>
                            <li><a href="#"onclick="confirmLogout()">Logout</a></li>
                        <?php else : ?>
                            <li><a href="register.php">Sign Up</a></li>
                        <?php endif; ?>
						
						
                    </ul>
                </div>
                <!-- #Nav Ends -->

            </div>
        </div>

    </div>
    <!-- #Header Starts -->

    <div class="container">

        <!-- Header Starts -->
        <div class="header">
		<a href="index.php"class="pinnacle-link">
		  <p class="pinnacle-text">Pinnacle Properties</p>
		  </a>
              <a href="index.php" class="svg">
            
         <svg xmlns="https://www.w3.org/2000/svg" viewBox="  100 64" width="150" height="64" id="svg"><g data-name="19-browser"><path d="M63 5v4H1V5a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4z" style="fill: rgb(255, 147, 107);" class="svg-1"></path><path d="M63 9v50a4 4 0 0 1-4 4H5a4 4 0 0 1-4-4V9z" style="fill: rgb(242, 246, 252);" class="svg-2"></path><path d="M59 1h-5a4 4 0 0 1 4 4v4h5V5a4 4 0 0 0-4-4z" style="fill: rgb(255, 112, 69);" class="svg-3"></path><path d="M58 9v50a4 4 0 0 1-4 4h5a4 4 0 0 0 4-4V9z" style="fill: rgb(233, 237, 245);" class="svg-4"></path><path d="M5 1h5a4 4 0 0 0-4 4v4H1V5a4 4 0 0 1 4-4z" style="fill: rgb(255, 112, 69);" class="svg-5"></path><path d="M6 9v50a4 4 0 0 0 4 4H5a4 4 0 0 1-4-4V9z" style="fill: rgb(233, 237, 245);" class="svg-6"></path><path d="M28 39H8V28.594l-2 1.09v-6.278l2-1.09V17h6v2.044l4-2.183 12 6.545v6.278l-2-1.09z" style="fill: rgb(156, 156, 156);" class="svg-7"></path><rect x="38" y="44" width="20" height="6" rx="2" ry="2" style="fill: rgb(210, 235, 90);" class="svg-8"></rect><rect x="8" y="44" width="20" height="6" rx="2" ry="2" style="fill: rgb(101, 177, 252);" class="svg-9"></rect><path d="M56 47H40a2 2 0 0 1-1.929-1.5A1.966 1.966 0 0 0 38 46v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a1.966 1.966 0 0 0-.071-.5A2 2 0 0 1 56 47z" style="fill: rgb(180, 210, 65);" class="svg-10"></path><path d="M26 47H10a2 2 0 0 1-1.929-1.5A1.966 1.966 0 0 0 8 46v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a1.966 1.966 0 0 0-.071-.5A2 2 0 0 1 26 47z" style="fill: rgb(74, 152, 247);" class="svg-11"></path><path style="fill: rgb(207, 207, 207);" d="M56 18v4H40v-4h16z" class="svg-12"></path><path style="fill: rgb(74, 152, 247);" d="M52 22h4v16h-4zM44 22h4v16h-4z" class="svg-13"></path><path style="fill: rgb(101, 177, 252);" d="M48 22h4v16h-4zM40 22h4v16h-4z" class="svg-14"></path><path style="fill: rgb(207, 207, 207);" d="M45 47v7l2-2 4 4 3-3-4-4 2-2h-7z" class="svg-15"></path><path style="fill: rgb(178, 135, 109);" d="M12 30h4v8h-4z" class="svg-16"></path><path style="fill: rgb(150, 104, 87);" d="M14 30h2v8h-2zM13 18v2.73l-4 2.18V18h4z" class="svg-17"></path><path style="fill: rgb(178, 135, 109);" d="M11 18H9v4.91l2-1.09V18z" class="svg-18"></path><path style="fill: rgb(163, 212, 255);" d="M19 30h5v4h-5z" class="svg-19"></path><path style="fill: rgb(101, 177, 252);" d="M19 32h5v2h-5z" class="svg-20"></path><path d="M24 30h-5v4h5zm3-3.09V38H16v-8h-4v8H9V26.91L18 22z" style="fill: rgb(247, 247, 247);" class="svg-21"></path><path style="fill: rgb(207, 207, 207);" d="m18 22-9 4.91v2L18 24l9 4.91v-2L18 22z" class="svg-22"></path><path style="fill: rgb(255, 147, 107);" d="M13 20.73 18 18l11 6v4l-2-1.09L18 22l-9 4.91L7 28v-4l2-1.09 4-2.18z" class="svg-23"></path><path style="fill: rgb(255, 112, 69);" d="m18 20-9 4.91L7 26v2l2-1.09L18 22l9 4.91L29 28v-2l-2-1.09L18 20z" class="svg-24"></path><path d="M59 0H5a5.006 5.006 0 0 0-5 5v54a5.006 5.006 0 0 0 5 5h54a5.006 5.006 0 0 0 5-5V5a5.006 5.006 0 0 0-5-5zM5 2h54a3 3 0 0 1 3 3v3H2V5a3 3 0 0 1 3-3zm54 60H5a3 3 0 0 1-3-3V10h60v49a3 3 0 0 1-3 3z" class="svg-25"></path><path d="M4 4h2v2H4zM8 4h2v2H8zM12 4h2v2h-2zM40 39h16a1 1 0 0 0 1-1V18a1 1 0 0 0-1-1H40a1 1 0 0 0-1 1v20a1 1 0 0 0 1 1zm1-16h2v14h-2zm10 0v14h-2V23zm-4 14h-2V23h2zm6 0V23h2v14zm2-18v2H41v-2zM26 43H10a3 3 0 0 0-3 3v2a3 3 0 0 0 3 3h16a3 3 0 0 0 3-3v-2a3 3 0 0 0-3-3zm1 5a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1zM56 43H40a3 3 0 0 0-3 3v2a3 3 0 0 0 3 3h3v-2h-3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v2a3 3 0 0 0 3-3v-2a3 3 0 0 0-3-3z" class="svg-26"></path><path d="m51.414 49 1.293-1.293A1 1 0 0 0 52 46h-7a1 1 0 0 0-1 1v7a1 1 0 0 0 1.707.707L47 53.414l3.293 3.293a1 1 0 0 0 1.414 0l3-3a1 1 0 0 0 0-1.414zM51 54.586l-3.293-3.293a1 1 0 0 0-1.414 0l-.293.293V48h3.586l-.293.293a1 1 0 0 0 0 1.414L52.586 53zM29.479 23.122l-11-6a1 1 0 0 0-.958 0L14 19.043V18a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v4.315l-1.479.807A1 1 0 0 0 6 24v4a1 1 0 0 0 1.479.878L8 28.594V38a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1v-9.406l.521.284A1 1 0 0 0 30 28v-4a1 1 0 0 0-.521-.878zM10 19h2v1.134l-2 1.09zm3 18v-6h2v6zm13 0h-9v-7a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v7h-1v-9.5l8-4.364 8 4.364zm2-10.685-9.521-5.193a1 1 0 0 0-.958 0L8 26.315v-1.721l10-5.455 10 5.455z" class="svg-27"></path><path d="M18 34a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-5a1 1 0 0 0-1 1zm2-3h3v2h-3z" class="svg-28"></path></g></svg>
        </a>

        

            <ul class="pull-right">
			  <?php if (isset($_SESSION['broker_id'])) : ?>
                       <li><a href="create.php" class="btn btn-primary">Create Property</a></li>

          
        <?php endif; ?>
            </ul>
        </div>
        <!-- #Header Starts -->
    </div>
<script>
    function confirmLogout() {
        $('#logoutModal').modal('show');
		  // Add a class to indicate that the animation is complete
       
    }
	
		
</script>
</body>
<div class="modal fadSe" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutModalLabel">Logout Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to log out?
            </div>
            <div class="modal-footer">
                
                <a href="logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
</div>

</html>