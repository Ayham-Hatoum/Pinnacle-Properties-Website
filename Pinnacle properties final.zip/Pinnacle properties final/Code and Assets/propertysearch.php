 <?php
// Sample database connection
include 'header.php';

$dbConnection = mysqli_connect("sql302.infinityfree.com", "if0_37600132", "JcG9eE91so3L6mj", "if0_37600132_realestate");
if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve search parameters
$search = mysqli_real_escape_string($dbConnection, $_GET['search'] ?? '');
$propertyType = mysqli_real_escape_string($dbConnection, $_GET['property_type'] ?? '');
$governate = mysqli_real_escape_string($dbConnection, $_GET['governate'] ?? '');
$minPrice = mysqli_real_escape_string($dbConnection, $_GET['min_price'] ?? '');
$maxPrice = mysqli_real_escape_string($dbConnection, $_GET['max_price'] ?? '');

// Build the WHERE clause based on non-empty search parameters
$whereClause = [];
if (!empty($search)) {
    $whereClause[] = "pName LIKE '%$search%'";
}
if (!empty($propertyType)) {
    $whereClause[] = "pType = '$propertyType'";
}
if (!empty($governate)) {
    $whereClause[] = "pGovernate = '$governate'";
}
if (!empty($minPrice) && !empty($maxPrice)) {
    $whereClause[] = "pPrice BETWEEN '$minPrice' AND '$maxPrice'";
}

// Perform database query based on search parameters
$query = "SELECT property.*, broker.bId, broker.bFirstName, broker.bLastName, broker.bEmail, broker.bMobileNumber 
          FROM property 
          LEFT JOIN broker ON property.bId = broker.bId";
if (!empty($whereClause)) {
    $query .= " WHERE " . implode(" AND ", $whereClause);
}

$result = mysqli_query($dbConnection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Search Results</title>
    <style>
        .property-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 16px;
            opacity: 0; /* Hide the table initially */
            animation: fadeIn 1.5s ease-in-out forwards; /* Fade-in animation */
        }

        th, td {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: left;
            background-color: #f8f8f8;
        }

        th {
            background-color: #f2f2f2;
            font-size: 18px;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        .sold-out-watermark {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 0, 0, 0.5);
            color: white;
            font-size: 24px;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2;
            pointer-events: none; /* Allow clicking through the watermark */
        }
    </style>
</head>
<body>

<?php
if ($result && mysqli_num_rows($result) > 0) {
    // Display search results in a table
    echo '<table class="property-table">';
    echo '<tr>';
    echo '<th>Property Name</th>';
    echo '<th>Property Type</th>';
    echo '<th>Area (m²)</th>'; // Updated Area column
    echo '<th>Description</th>';
    echo '<th>Location</th>';
    echo '<th>Governate</th>';
    echo '<th>Date Listed</th>';
    echo '<th>Price</th>';
    echo '<th>Image</th>';
    echo '<th>Created By</th>';
    echo '<th>Email</th>';
    echo '<th>Phone Number</th>';
    echo '</tr>';

    while ($property = mysqli_fetch_assoc($result)) {
        // Check if the property should be displayed
        if ($property['pSoldOut'] == 'Yes' && date('Y-m-d') > $property['pSoldOutDate'] && $property['pSoldOutDate'] != '0000-00-00') {
            continue; // Skip to the next iteration
        }

        echo '<tr class="property-row">';
        echo '<td>' . $property['pName'] . '</td>';
        echo '<td>' . $property['pType'] . '</td>';
        echo '<td>' . $property['pArea'] . ' m²</td>'; // Display Area column with m²
        echo '<td>' . $property['pDesc'] . '</td>';
        echo '<td>' . $property['pLocation'] . '</td>';
        echo '<td>' . $property['pGovernate'] . '</td>';
        echo '<td>' . $property['oDate'] . '</td>';
        echo '<td>$' . $property['pPrice'] . '</td>';
        echo '<td style="position: relative;">'; // Added position: relative
       
        // Check if the property is sold out
        if ($property['pSoldOut'] == 'Yes') {
            // Check if the current date is before pSoldOutDate
            if (date('Y-m-d') <= $property['pSoldOutDate'] && $property['pSoldOutDate'] != '0000-00-00') {
                echo '<img src="' . $property['pImage'] . '" alt="Property Image" style="max-width: 100px; max-height: 100px;">';
                echo '<div class="sold-out-watermark">Sold Out</div>';
            }
            // If the current date is after pSoldOutDate, skip the image
        } else {
            // Display the image without the watermark for properties that are not sold out
            echo '<img src="' . $property['pImage'] . '" alt="Property Image" style="max-width: 100px; max-height: 100px;">';
        }

        echo '</td>';
        echo '<td style="display: none;">' . $property['bId'] . '</td>'; // Hidden broker ID
        echo '<td>' . $property['bFirstName'] . ' ' . $property['bLastName'] . '</td>';
        echo '<td>' . $property['bEmail'] . '</td>';
        echo '<td>' . $property['bMobileNumber'] . '</td>';
        echo '</tr>';
    }

    // After the while loop, close the table
    echo '</table>';
} else {
    echo '<p>No results found.</p>';
}

// Close the database connection
mysqli_close($dbConnection);
?>

</body>
</html>