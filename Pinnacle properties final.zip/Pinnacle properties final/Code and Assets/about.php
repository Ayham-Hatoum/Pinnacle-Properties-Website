 <!DOCTYPE html>
<html lang="en">

<head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59D5uPZB7Wce1k3L2K4lT" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js" integrity="sha384-J3SOCE2Tu/d7d54pN5XGi5Z6JHPBgccD1HuQtmDWN5u5/1+Iy3fzX3LmC66F3jV+" crossorigin="anonymous"></script>
</head>
<?php include 'header.php';?>

<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="index.php">Home</a> / About Us</span>
    <h2>About Us</h2>
  </div>
</div>
<!-- banner -->

<div class="container">
  <div class="spacer">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2 text-center">
        <div class="about-image">
		
          <img src="images/about2.jpg" class="img-responsive thumbnail" alt="realestate" data-aos="fade-in" data-aos-duration="1000">
		  <style>
		.img-responsive thumbnail{
			display: center;
		}
		</style>
        </div>
        <div class="about-content" data-aos="fade-in" data-aos-duration="1000">
         
          <h3>Pinnacle Properties</h3>
          <p>
            At Pinnacle Properties, we are committed to delivering exceptional real estate services. Our mission is to
                turn houses into dream homes and assist you in discovering the perfect property that aligns with your
                vision and lifestyle.
          </p>
          <p>
            Thank you for being a part of our journey!
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php';?>
</html