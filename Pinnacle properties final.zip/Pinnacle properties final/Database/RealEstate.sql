/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     12/20/2023 12:05:56 PM                       */
/*==============================================================*/
DROP DATABASE IF EXISTS realestate;
CREATE DATABASE realestate;
USE realestate;

GRANT SELECT, INSERT, UPDATE, delete
	on realestate.*
	TO ayham@localhost
	IDENTIFIED BY 'ayham';

drop table if exists Broker;

drop table if exists Own;

drop table if exists Property;

drop table if exists Seller;

/*==============================================================*/
/* Table: Broker                                                */
/*==============================================================*/
create table Broker
(
   bId                  int not null auto_increment,
   bFirstName           varchar(50) not null,
   bLastName            varchar(50) not null,
   bUserName            varchar(50) not null,
   bPassword            varchar(50) not null,
   bEmail               varchar(50) not null,
   bMobileNumber        int not null,
   bRole                numeric(8,0) not null,
   bRoleDescription     text not null,
   bPic                             text,
   primary key (bId)
);

/*==============================================================*/
/* Table: Own                                                   */
/*==============================================================*/
create table Own
(
   sId                  int not null,
   pId                  int not null,
   primary key (sId, pId)
);

/*==============================================================*/
/* Table: Property                                              */
/*==============================================================*/
create table Property
(
   pId                  int not null auto_increment,
   bId                  int not null,
   pName                varchar(100) not null,
   pDesc                text,
   pType                varchar(100) not null,
   pGovernate           varchar(50) not null,
   pLocation            varchar(50) not null,
   pImage               text,
   oDate                date,
   pPrice                int not null,
   pArea                 int not null, 
   pFeatured         text,
   pSoldOut           text, 
   pSoldOutDate  date, 
   primary key (pId)
);

/*==============================================================*/
/* Table: Seller                                                */
/*==============================================================*/
create table Seller
(
   sId                  int not null auto_increment,
   sFirstName           varchar(50) not null,
   sLastName            varchar(50) not null,
   sDoB                 date not null,
   sEmail               varchar(50) not null,
   sMobileNumber text, 
   bId                      int not null,
   primary key (sId)
);

alter table Own add constraint FK_Own foreign key (sId)
      references Seller (sId) on delete restrict on update restrict;

alter table Own add constraint FK_Own2 foreign key (pId)
      references Property (pId) on delete restrict on update restrict;

alter table Property add constraint FK_Offer foreign key (bId)
      references Broker (bId) on delete restrict on update restrict;

alter table SellerS add constraint FK_Offer foreign key (bId)
      references Broker (bId) on delete restrict on update restrict;

