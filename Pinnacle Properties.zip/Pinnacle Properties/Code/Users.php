<?php

// Check if the broker is logged in and has admin privileges

// Your database connection code here...
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted to block or delete user
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['block'])) {
        // Block the user
        $blockId = mysqli_real_escape_string($dbConnection, $_POST['block']);
        $blockUserQuery = "UPDATE broker SET bRole = 0, bRoleDescription = 'This user has been blocked' WHERE bId = '$blockId'";
        mysqli_query($dbConnection, $blockUserQuery);
    } elseif (isset($_POST['unblock'])) {
        // Unblock the user
        $unblockId = mysqli_real_escape_string($dbConnection, $_POST['unblock']);
        $unblockUserQuery = "UPDATE broker SET bRole = 1, bRoleDescription = 'The user is a broker and can create and list properties.' WHERE bId = '$unblockId'";
        mysqli_query($dbConnection, $unblockUserQuery);
    } elseif (isset($_POST['delete'])) {
        // Delete the user along with associated properties, sellers, and own records
        $deleteId = mysqli_real_escape_string($dbConnection, $_POST['delete']);
        $deleteUserQuery = "DELETE broker, property, seller, own
                            FROM broker
                            LEFT JOIN property ON broker.bId = property.bId
                            LEFT JOIN own ON property.pId = own.pId
                            LEFT JOIN seller ON own.sId = seller.sId
                            WHERE broker.bId = '$deleteId'";
        mysqli_query($dbConnection, $deleteUserQuery);
    }
}

// Fetch all users except the current admin
$fetchUsersQuery = "SELECT bId, bFirstName, bLastName, bEmail, bRole, bRoleDescription
                    FROM broker
                    WHERE bRole != 3";

$usersResult = mysqli_query($dbConnection, $fetchUsersQuery);

?>

<!-- HTML for displaying users and actions -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <style>
         <?php include 'styles.css'; ?> /* Include external CSS file for styling */
        
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            color: #333;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: auto;
            text-align: center;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center;
            align-items: center;
        }

        .action-buttons button {
            padding: 8px 15px;
            cursor: pointer;
        }

        .block-btn {
            background-color: #ff6666;
            color: white;
            border: none;
        }

        .unblock-btn {
            background-color: #66ff66;
            color: white;
            border: none;
        }

        .delete-btn {
            background-color: #333;
            color: white;
            border: none;
        }
    </style>
</head>
<body>

    <?php include 'header.php'; ?> <!-- Include header.php file for the header -->

    <div class="container">
        <h2>Users</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Role Description</th>
                <th>Action</th>
            </tr>
            <?php
            while ($user = mysqli_fetch_assoc($usersResult)) {
                echo "<tr>";
                echo "<td>{$user['bId']}</td>";
                echo "<td>{$user['bFirstName']}</td>";
                echo "<td>{$user['bLastName']}</td>";
                echo "<td>{$user['bEmail']}</td>";
                echo "<td>{$user['bRole']}</td>";
                echo "<td>{$user['bRoleDescription']}</td>";
                echo "<td class='action-buttons'>";
              
                
                if ($user['bRole'] == 1) {
                    // User is not blocked
                    echo "<form method='post' action='Users.php' onsubmit='return confirm(\"Are you sure you want to block this user?\")'>";
                    echo "<input type='hidden' name='block' value='{$user['bId']}'>";
                    echo "<button class='block-btn' type='submit'>Block</button>";
                    echo "</form>";
                } elseif ($user['bRole'] == 0) {
                    // User is blocked
                    echo "<form method='post' action='Users.php' onsubmit='return confirm(\"Are you sure you want to unblock this user?\")'>";
                    echo "<input type='hidden' name='unblock' value='{$user['bId']}'>";
                    echo "<button class='unblock-btn' type='submit'>Unblock</button>";
                    echo "</form>";
                }

                echo "<form method='post' action='Users.php' onsubmit='return confirm(\"Are you sure you want to delete this user?\")'>";
                echo "<input type='hidden' name='delete' value='{$user['bId']}'>";
                echo "<button class='delete-btn' type='submit'>Delete</button>";
                echo "</form>";
                
                echo "<a href='UserListings.php?bId={$user['bId']}'>View Listings</a>";

                echo "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>

</body>
</html>


