<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
        integrity="sha384-rk+/8wABKLaWU+8VJkG2L0Ahg6KA6VIsjzVzCr5F0BXqMDnT+Z6njiLtvBCKpjr"
        crossorigin="anonymous">
    <style>
        /* Add styles for the background image and fade-in effect */
        .inside-banner {
            background-image: url('images/ContactUs.jpg');
            background-size: cover;
            background-position: center;
            color: #fff; /* Set text color to white for better visibility */
            padding: 100px 0;
            text-align: center;
            animation: fadeIn 1.5s ease-in-out; /* Fade-in animation */
        }

        .inside-banner h2 {
            margin-bottom: 20px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <?php include 'header.php';?>
    <!-- banner -->
    <div class="inside-banner">
        <div class="container">
            <span class="pull-right"><a href="#">Home</a> / Support</span>
            <h2>Support</h2>
        </div>
    </div>
    <!-- banner -->

    <div class="container">
        <div class="spacer">
            <div class="row contact">
                <div class="col-md-6 col-md-offset-3">
                    <div class="contact-info">
					 <p>If you need assistance or have any inquiries, feel free to reach out to us via email or WhatsApp.
                            Our support team is here to help you!</p>
                        <div class="contact-item">
                            <div class="icon"><i class="fas fa-envelope"></i></div>
                            <div class="text">
                                <span class="glyphicon glyphicon-envelope"></span> <a
                                    href="mailto:ayhamhatoum8@gmail.com">ayhamhatoum8@gmail.com</a>
                            </div>
                        </div>
                        <div class="contact-item">
                            <div class="icon"><i class="fab fa-whatsapp"></i></div>
                            <div class="text">
                                <span class="glyphicon glyphicon-earphone"></span><a
                                    href="https://wa.me/96181331261" target="_blank">(+961) 81331261</a> (WhatsApp)
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php';?>
</body>

</html>
