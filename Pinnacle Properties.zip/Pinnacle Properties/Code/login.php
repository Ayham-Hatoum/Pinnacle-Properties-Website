<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Your database connection code here...

    // Sample connection code:
    $dbConnection = mysqli_connect("localhost", "root", "", "realestate");

    if (!$dbConnection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $bUserName = mysqli_real_escape_string($dbConnection, $_POST['username']);
    $bPassword = $_POST['password'];

    $sql = "SELECT bId, bUserName, bPassword, bRole FROM broker WHERE bUserName = '$bUserName'";
    $result = mysqli_query($dbConnection, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        if ($row) {
            // Check if the account is blocked (bRole is 0)
            if ($row['bRole'] == 0) {
                  echo '<script>alert("Your account has been blocked. Please contact us.");</script>';
                echo '<script>window.location.href = "contact.php";</script>';
                exit();
            }

            if ($row['bPassword'] == $bPassword) {
                $_SESSION['broker_id'] = $row['bId'];
                $_SESSION['broker_username'] = $row['bUserName'];

                // Set a "Remember Me" cookie if checked
                if (isset($_POST['remember_me']) && $_POST['remember_me'] == 1) {
                    $token = bin2hex(random_bytes(16));
                    setcookie('remember_token', $token, time() + (86400 * 30), "/");
                }

                header("Location: index.php");
                exit();
            } else {
                echo '<script>alert("Invalid password");</script>';
            }
        } else {
            echo '<script>alert("Invalid username");</script>';
        }
    } else {
        echo '<script>alert("Error in database query");</script>';
    }

    mysqli_close($dbConnection);
}
?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="index.php">
        <img src="images/Real Estate.gif" alt="Logo" class="logo"></a></span>
    <h2>Log in</h2>
</div>
</div>
<!-- banner -->

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        background-image: url('images/Real Estate Logo.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        height: 100vh;
        margin: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: backgroundAnimation 5s linear infinite;
    }

    @keyframes backgroundAnimation {
        0% {
            background-position: 0% 50%;
        }
        50% {
            background-position: 100% 50%;
        }
        100% {
            background-position: 0% 50%;
        }
    }

    .container {
        max-width: 500px;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.1);
    }

    input[type="text"], input[type="password"] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    .logo {
        max-width: 150px;
        margin: 20px auto;
        display: block;
    }
	 .register-link {
        display: block;
        margin-top: 10px;
        text-align: center;
        color: #4CAF50;
        text-decoration: none;
        font-weight: bold;
    }

    .register-link:hover {
        color: #45a049;
    }
</style>

<div class="container">
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
 <input type="checkbox" id="remember_me" name="remember_me">
        <label for="remember_me">Remember Me</label><br><br>
        <input type="submit" value="Log in">
    </form>
	  <!-- Registration link -->
    <a href="register.php" class="register-link">Not registered yet? Sign up here</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
