<?php include 'header.php'; ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Properties Listing</title>
    <style>
           .container2 {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 00px;
            box-sizing: border-box;
            width: 100%; /* Adjust the width as needed */
            background-color: #ecf0f1;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .property-table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 80px; /* Increased distance between tables */
        }

        .property-table th, .property-table td {
            padding: 15px;
            text-align: center; /* Center the text in cells */
            border-bottom: 1px solid #ddd;
        }

        .property-table th {
            background-color: #3498db;
            color: #fff;
        }

        .property-table tr:hover {
            background-color: #f5f5f5;
        }

        .img-responsive {
            max-width: 20%;
            height: auto;
            display: block;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .bold-text {
            font-weight: bold;
        }

        .property-link {
            display: inline-block;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            background-color: #e74c3c;
            border: 1px solid #e74c3c;
            border-radius: 4px;
            padding: 10px 15px;
            transition: background-color 0.3s, color 0.3s;
        }

        .property-link:hover {
            background-color: #c0392b;
            color: #fff;
        }

        .sold-out-watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 24px;
            color: white;
            background-color: rgba(255, 0, 0, 0.5);
            padding: 10px;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <header>
        
    </header>
    <div class="container2">
        <h2>All Properties Listing</h2>
          <?php

        // Fetch current broker's ID if logged in or signed up
        $currentBrokerID = $_SESSION['broker_id']; // You need to implement this based on your authentication logic

        // Sample database connection
        $dbConnection = mysqli_connect("localhost", "root", "", "realestate");

        if (!$dbConnection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Sample query to fetch all properties with broker details
        $allPropertiesQuery = "SELECT property.*, broker.bId, broker.bFirstName, broker.bLastName, broker.bEmail, broker.bMobileNumber, own.sId FROM property LEFT JOIN broker ON property.bId = broker.bId LEFT JOIN own ON property.pId = own.pId";
        $allPropertiesResult = mysqli_query($dbConnection, $allPropertiesQuery);

        // Check if there are properties in the database
        if ($allPropertiesResult && mysqli_num_rows($allPropertiesResult) > 0) {
            // While loop to iterate through fetched properties
            while ($property = mysqli_fetch_assoc($allPropertiesResult)) {
                // Check if the property is sold out
                $isSoldOut = $property['pSoldOut'] == 'Yes' && date('Y-m-d') <= $property['pSoldOutDate'] && $property['pSoldOutDate'] != '0000-00-00';

                // Fetch seller details based on sId
                $sId = $property['sId'];
                $sellerQuery = "SELECT * FROM seller WHERE sId = '$sId'";
                $sellerResult = mysqli_query($dbConnection, $sellerQuery);
                $seller = mysqli_fetch_assoc($sellerResult);

                echo '<table class="property-table">';
                echo '<thead><tr><th colspan="2">Property Details</th></tr></thead>';
                echo '<tbody>';
                echo '<tr>';
                echo '<td class="bold-text">Type:</td>';
                echo '<td>' . (isset($property['pType']) ? $property['pType'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Image:</td>';
                
                // Check if the property is sold out and meet the additional condition
                if ($isSoldOut) {
                    echo '<td style="position: relative;">';
                    echo '<img src="' . $property['pImage'] . '" class="img-responsive" alt="property"/>';

                    // Display watermark if the property is sold out
                    echo '<div class="sold-out-watermark">Sold Out</div>';
                    echo '</td>';
                } else {
                    echo '<td><img src="' . (isset($property['pImage']) ? $property['pImage'] : '') . '" class="img-responsive" alt="property"/></td>';
                }
                
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Price:</td>';
                echo '<td>$' . (isset($property['pPrice']) ? $property['pPrice'] : '') . '</td>';
                echo '</tr>';
                // Move pArea after pPrice
                echo '<tr>';
                echo '<td class="bold-text">Area:</td>';
                echo '<td>' . (isset($property['pArea']) ? $property['pArea'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Description:</td>';
                echo '<td>' . (isset($property['pDesc']) ? $property['pDesc'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Location:</td>';
                echo '<td>' . (isset($property['pLocation']) ? $property['pLocation'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Governate:</td>';
                echo '<td>' . (isset($property['pGovernate']) ? $property['pGovernate'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Created By:</td>';
                echo '<td>' . (isset($property['bFirstName']) ? $property['bFirstName'] : '') . ' ' . (isset($property['bLastName']) ? $property['bLastName'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Email:</td>';
                echo '<td>' . (isset($property['bEmail']) ? $property['bEmail'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Mobile:</td>';
                echo '<td>' . (isset($property['bMobileNumber']) ? $property['bMobileNumber'] : '') . '</td>';
                echo '</tr>';
                // Display seller details
                echo '<tr>';
                echo '<td class="bold-text">Seller:</td>';
                echo '<td>' . (isset($seller['sFirstName']) ? $seller['sFirstName'] : '') . ' ' . (isset($seller['sLastName']) ? $seller['sLastName'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Email:</td>';
                echo '<td>' . (isset($seller['sEmail']) ? $seller['sEmail'] : '') . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td class="bold-text">Mobile:</td>';
                echo '<td>' . (isset($seller['SMobileNumber']) ? $seller['SMobileNumber'] : '') . '</td>';
                echo '</tr>';
                echo '</tbody>';
                echo '</table>';
            }
        } else {
            echo '<p>No properties found.</p>';
        }

        mysqli_close($dbConnection);
        ?>
    </div>
</body>
</html>
