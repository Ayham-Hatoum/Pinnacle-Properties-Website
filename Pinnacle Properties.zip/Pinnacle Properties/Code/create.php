<?php
include 'header.php';
// Check if the broker is logged in
if (!isset($_SESSION['broker_id'])) {
    header("Location: login.php");
    exit();
}

// Your database connection code here...
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

$bId = $_SESSION['broker_id'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract property details
    $pName = mysqli_real_escape_string($dbConnection, $_POST['pName']);
    $pDesc = mysqli_real_escape_string($dbConnection, $_POST['pDesc']);
    $pType = mysqli_real_escape_string($dbConnection, $_POST['pType']);
    $pGovernate = $_POST['pGovernate'];
    $pLocation = mysqli_real_escape_string($dbConnection, $_POST['pLocation']);
    $pPrice = mysqli_real_escape_string($dbConnection, $_POST['pPrice']);
    $pArea = mysqli_real_escape_string($dbConnection, $_POST['pArea']); // Added area field
    $oDate = date("Y-m-d"); // Current date

    // Create a directory for each broker
    $targetDir = "PropertyImage/broker_$bId/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Upload multiple images
    $uploadedFiles = [];

    if (!empty($_FILES["pImage"]["name"])) {
        // If multiple files are uploaded
        if (is_array($_FILES["pImage"]["name"])) {
            $fileCount = count($_FILES["pImage"]["name"]);

            for ($i = 0; $i < $fileCount; $i++) {
                $targetFile = $targetDir . basename($_FILES["pImage"]["name"][$i]);
                move_uploaded_file($_FILES["pImage"]["tmp_name"][$i], $targetFile);
                $uploadedFiles[] = $targetFile;
            }
        } else { // If a single file is uploaded
            $targetFile = $targetDir . basename($_FILES["pImage"]["name"]);
            move_uploaded_file($_FILES["pImage"]["tmp_name"], $targetFile);
            $uploadedFiles[] = $targetFile;
        }
    }

    // Convert array of uploaded files to a string for database storage
    $imageString = implode(",", $uploadedFiles);

    // Extract seller ID from the form
    $sId = mysqli_real_escape_string($dbConnection, $_POST['seller_id']);

    // Insert property into the database
    $insertPropertyQuery = "INSERT INTO property (bId, pName, pDesc, pType, pGovernate, pLocation, pImage, pPrice, pArea, pSoldOut, pFeatured, oDate) 
                            VALUES ('$bId', '$pName', '$pDesc', '$pType', '$pGovernate', '$pLocation', '$imageString', '$pPrice', '$pArea', 'No', 'No', '$oDate')";

    if (mysqli_query($dbConnection, $insertPropertyQuery)) {
        // Insert into the 'own' entity
        $pId = mysqli_insert_id($dbConnection);
        $insertOwnQuery = "INSERT INTO own (pId, sId) VALUES ('$pId', '$sId')";
        mysqli_query($dbConnection, $insertOwnQuery);

         echo '<script>
                setTimeout(function() {
                    window.location.href = "index.php";
                }, 1000); // Adjust the delay time (in milliseconds) as needed
              </script>';
        exit();
    } else {
        // Set alert message in session
        $_SESSION['alert_message'] = "Error creating property";

        // Redirect to index.php after a delay
        echo '<script>
                setTimeout(function() {
                    window.location.href = "index.php";
                }, 1000); // Adjust the delay time (in milliseconds) as needed
              </script>';
    }
}

// Fetch a list of sellers associated with the broker
$fetchSellersQuery = "SELECT sId, sFirstName, sLastName FROM seller WHERE bId = '$bId'";
$sellersResult = mysqli_query($dbConnection, $fetchSellersQuery);

// Close the database connection
mysqli_close($dbConnection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Property</title>
    <style>
        

        .container2 {
            font-family: 'Verdana', sans-serif;
            background-color: #f5f5f5;
            margin: 30vh auto; /* Center vertically and lower by 30% of viewport height */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 95vh; /* Lowered height to 40% of viewport height */
        }

        form {
            max-width: 600px;
            width: 100%;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 5px 0px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-in-out;
            display: flex;
            flex-direction: column;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        textarea,
        select,
        input[type="file"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s ease-in-out;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        textarea:focus,
        select:focus,
        input[type="file"]:focus {
            border-color: #4CAF50;
        }

        input[type="checkbox"] {
            margin-top: 10px;
        }

        #seller_fields {
            display: none;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin-top: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        select {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s ease-in-out;
        }

        select:focus {
            border-color: #4CAF50;
        }

        a {
            color: #4CAF50;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <!-- The form for property creation with adjustments for seller information -->
    <div class="container2">

        <form action="create.php" method="post" enctype="multipart/form-data">
		        <h2>Create Property</h2>

            <label for="pName">Property Name:</label>
            <input type="text" id="pName" name="pName" required>

            <label for="pDesc">Description:</label>
            <textarea id="pDesc" name="pDesc" required></textarea>

            <label for="pType">Property Type:</label>
            <select id="pType" name="pType" required>
                <option value="">Property Type</option>
                <option value="Apartment for sale">Apartment for sale</option>
                <option value="Apartment for rent">Apartment for rent</option>
                <option value="Building for sale">Building for sale</option>
                <option value="Land for sale">Land for sale</option>
            </select>

            <label for="pGovernate">Governate:</label>
            <select id="pGovernate" name="pGovernate" required>
                <option value="">Select Governate</option>
                <option value="Beirut">Beirut</option>
                <option value="Mount Lebanon">Mount Lebanon</option>
                <option value="Akkar">Akkar</option>
                <option value="Baalbek-Hermel">Baalbek-Hermel</option>
                <option value="Beqaa">Beqaa</option>
                <option value="Keserwan-Jbeil">Keserwan-Jbeil</option>
                <option value="Nabatieh">Nabatieh</option>
                <option value="North">North</option>
                <option value="South">South</option>
            </select>

            <label for="pLocation">Location:</label>
            <input type="text" id="pLocation" name="pLocation" required>

            <label for="pArea">Area:</label>
            <input type="text" id="pArea" name="pArea" required>

            <label for="pPrice">Price:</label>
            <input type="text" id="pPrice" name="pPrice" required>

            <label for="seller_id">Select Seller or <a href="sellercreate.php">Create New Seller</a>:</label>
            <select id="seller_id" name="seller_id">
                <?php
                while ($seller = mysqli_fetch_assoc($sellersResult)) {
                    echo "<option value='{$seller['sId']}'>ID: {$seller['sId']} - {$seller['sFirstName']} {$seller['sLastName']}</option>";
                }
                ?>
            </select>

            <label for="pImage">Upload Image:</label>
            <input type="file" id="pImage" name="pImage" accept="image/*">

            <input type="submit" value="Create Property">
        </form>
    </div>
</body>
</html>
