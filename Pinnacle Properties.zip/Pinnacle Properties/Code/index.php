<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Real Estate Website</title>
    <!-- Add jQuery and Owl Carousel CSS and JS files to the head section of your HTML -->
 

    <!-- Your existing head content -->
    <!-- ... -->
	<script>
    // Add $ sign to min and max price inputs before form submission
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('propertySearchForm').addEventListener('submit', function(event) {
            var minPriceInput = document.getElementById('minPrice');
            var maxPriceInput = document.getElementById('maxPrice');

            // Check if the input values are not empty and do not already contain a $ sign
            if (minPriceInput.value.trim() !== '' && !minPriceInput.value.includes('$')) {
                minPriceInput.value = minPriceInput.value.trim() + '$';
            }

            if (maxPriceInput.value.trim() !== '' && !maxPriceInput.value.includes('$')) {
                maxPriceInput.value = maxPriceInput.value.trim() + '$';
            }
        });
    });
</script>
</head>
<body>
<?php include'header.php';?>



<div class="">
    
<div id="slider" class="sl-slider-wrapper">
   <div class="sl-slider">
    <?php
    // Sample database connection
    $dbConnection = mysqli_connect("localhost", "root", "", "realestate");

    if (!$dbConnection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sample query to fetch unique random property ids that are not sold out
    $sql = "SELECT DISTINCT pID FROM property WHERE pSoldOut = 'No' AND pFeatured = 'No' ORDER BY RAND() LIMIT 5";
    $result = mysqli_query($dbConnection, $sql);

    // While loop to iterate through fetched property IDs
    while ($row = mysqli_fetch_assoc($result)) {
        $propertyId = $row['pID'];

        // Fetch additional details for the selected property
        $propertyDetailsQuery = "SELECT pID, pName, pDesc, pType, pGovernate, pLocation, pImage FROM property WHERE pID = $propertyId AND pSoldOut = 'No'";
        $propertyDetailsResult = mysqli_query($dbConnection, $propertyDetailsQuery);

        if ($propertyDetailsResult && mysqli_num_rows($propertyDetailsResult) > 0) {
            $property = mysqli_fetch_assoc($propertyDetailsResult);
            ?>
            <div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">
                <div class="sl-slide-inner">
                    <div class="bg-img" style="background-image: url('<?php echo $property['pImage']; ?>');"></div>
                    <h2><a href="#"><?php echo $property['pType']; ?></a></h2>
                    <blockquote>
                        <p><?php echo $property['pDesc']; ?></p>
                        <p class="location"><span class="glyphicon glyphicon-map-marker"></span> <?php echo $property['pLocation'] . ', ' . $property['pGovernate']; ?></p>
                        <!-- Additional information or formatting if needed -->
                        <a href="propertyview.php?id=<?php echo $property['pID']; ?>" class="btn-learn-more">More Details</a>
                    </blockquote>
                </div>
            </div>
            <?php
        }
    }

    mysqli_close($dbConnection);
    ?>
</div><!-- /sl-slider -->

</div><!-- /sl-slider-wrapper -->



        <nav id="nav-dots" class="nav-dots">
          <span class="nav-dot-current"></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </nav>

      </div><!-- /slider-wrapper -->
</div>


 <div class="banner-search">
        <div class="container"> 
            <!-- banner -->
            <h3>Property Search</h3>
            <div class="searchbar">
                <form id="propertySearchForm" action="propertysearch.php" method="GET">
                    <div class="row">
                        <div class="col-lg-6 col-sm-6">
                            <div class="row">
                                <div class="col-lg-4 col-sm-4">
                                    <select name="property_type" class="form-control">
                                        <option value="">Property Type</option>
                                        <option value="Apartment for sale">Apartment for sale</option>
                                        <option value="Apartment for rent">Apartment for rent</option>
                                        <option value="Building for sale">Building for sale</option>
                                        <option value="Land for sale">Land for sale</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 col-sm-4">
                                    <input type="text" name="governate" class="form-control" placeholder="Governate">
                                </div>
                                <div class="col-lg-4 col-sm-4">
                                    <div class="input-group">
                                        <span class="input-group-addon">$</span>
                                        <input type="text" name="min_price" id="minPrice" class="form-control" placeholder="Min Price">
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-addon">$</span>
                                        <input type="text" name="max_price" id="maxPrice" class="form-control" placeholder="Max Price">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success">Find Now</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>


    
    
<!-- banner -->
<div class="container">
   <div class="properties-listing spacer">
    <a href="property.php" class="pull-right viewall">View All Listing</a>
    <h2>Featured Properties</h2>

    <?php
    // Sample database connection
    $dbConnection = mysqli_connect("localhost", "root", "", "realestate");

    if (!$dbConnection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sample query to fetch featured property IDs that are not sold out
    $propertyIdQuery = "SELECT pID FROM property WHERE pFeatured = 'yes' AND pSoldOut = 'No' ORDER BY RAND() LIMIT 5";
    $propertyIdResult = mysqli_query($dbConnection, $propertyIdQuery);

    // Check if there are featured properties in the database
    if ($propertyIdResult && mysqli_num_rows($propertyIdResult) > 0) {
        $propertyIds = mysqli_fetch_all($propertyIdResult, MYSQLI_ASSOC);

        // Display each featured property as a banner
        echo '<div id="owl-example" class="owl-carousel">';
        foreach ($propertyIds as $property) {
            // Fetch property details based on ID
            $propertyDetailsQuery = "SELECT pID, pType, pImage, pPrice FROM property WHERE pID = " . $property['pID'];
            $propertyDetailsResult = mysqli_query($dbConnection, $propertyDetailsQuery);

            if ($propertyDetailsResult && mysqli_num_rows($propertyDetailsResult) > 0) {
                $propertyDetails = mysqli_fetch_assoc($propertyDetailsResult);

                // Display property details in the banner
                echo '<div class="properties">';
                echo '<div class="image-holder"><img src="' . $propertyDetails['pImage'] . '" class="img-responsive" alt="properties"/></div>';
                echo '<h4>' . $propertyDetails['pType'] . '</h4>';
                echo '<p class="price">$' . $propertyDetails['pPrice'] . '</p>';
                echo '<a class="btn btn-primary" href="propertyview.php?id=' . $propertyDetails['pID'] . '">View Details</a>';
                echo '</div>';
            }
        }
        echo '</div>';
    } else {
        echo '<p>No featured properties found or all are sold out.</p>';
    }

    mysqli_close($dbConnection);
    ?>
</div>


</div>
  </div>
  <div class="spacer">
    <div class="row">
     <div class="col-lg-6 col-sm-9 recent-view">
   <h3>About Us</h3>
   <p>Pinnacle Properties, created by Ayham Hatoum, aims to provide a platform for users to list properties and for other users to easily browse and view them. Our goal is to simplify the process of property transactions and make it convenient for individuals to find their desired properties.<br><a href="about.php">Learn More</a></p>
</div>

    <div class="col-lg-5 col-lg-offset-1 col-sm-3 recommended">
    <h3>Newest Properties</h3>
    <?php
    // Sample database connection
    $dbConnection = mysqli_connect("localhost", "root", "", "realestate");

    if (!$dbConnection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sample query to fetch 4 newest unique property IDs that are not sold out
    $newestPropertiesQuery = "SELECT DISTINCT pID FROM property WHERE pSoldOut = 'No' AND pFeatured = 'No'  ORDER BY oDate DESC LIMIT 4";
    $newestPropertiesResult = mysqli_query($dbConnection, $newestPropertiesQuery);

    // Check if any newest property IDs are found
    if ($newestPropertiesResult && mysqli_num_rows($newestPropertiesResult) > 0) {
        echo '<div id="myCarousel" class="carousel slide">';
        echo '<div class="carousel-inner">';

        // Loop through the newest property IDs
        $activeClass = 'active';
        while ($row = mysqli_fetch_assoc($newestPropertiesResult)) {
            $propertyID = $row['pID'];

            // Fetch property details based on the newest ID
            $propertyDetailsQuery = "SELECT pID, pType, pImage, pPrice FROM property WHERE pID = $propertyID";
            $propertyDetailsResult = mysqli_query($dbConnection, $propertyDetailsQuery);

            if ($propertyDetailsResult && mysqli_num_rows($propertyDetailsResult) > 0) {
                $propertyDetails = mysqli_fetch_assoc($propertyDetailsResult);

                // Display property details in the slider
                echo '<div class="item ' . $activeClass . '">';
                echo '<div class="row">';
                echo '<div class="col-lg-4"><img src="' . $propertyDetails['pImage'] . '" class="img-responsive" alt="properties"/></div>';
                echo '<div class="col-lg-8">';
                echo '<h5><a href="propertyview.php?id=' . $propertyDetails['pID'] . '">' . $propertyDetails['pType'] . '</a></h5>';
                echo '<p class="price">$' . $propertyDetails['pPrice'] . '</p>';
                echo '<a href="propertyview.php?id=' . $propertyDetails['pID'] . '" class="more">More Detail</a>';
                echo '</div>';
                echo '</div>';
                echo '</div>';

                $activeClass = ''; // Remove 'active' class after the first iteration
            }
        }

        echo '</div>';
        echo '</div>';
    } else {
        echo '<p>No newest properties found or all are sold out.</p>';
    }

    mysqli_close($dbConnection);
    ?>
</div>


    </div>
  </div>
</div>
 
<?php include'footer.php';?>

   
</body>
</html>
