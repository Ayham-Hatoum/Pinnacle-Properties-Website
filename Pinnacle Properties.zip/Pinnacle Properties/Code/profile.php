<?php
include 'header.php';

if (!isset($_SESSION['broker_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Your database connection code here...
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

$brokerId = $_SESSION['broker_id'];

// Fetch broker information
$sql = "SELECT * FROM broker WHERE bId = $brokerId";
$result = mysqli_query($dbConnection, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $brokerData = mysqli_fetch_assoc($result);
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broker Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            overflow: auto;
            animation: fadeIn 1s ease-out;
        }
		 .profile-image {
                width: 100px; /* Adjust the width as needed */
                height: 100px; /* Adjust the height as needed */
                border-radius: 50%;
                object-fit: cover;
                margin-right: 20px;
            }

        h1 {
            color: #4caf50;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2em;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
        }

        .profile-section, .links-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
            width: 80%;
            text-align: center;
            margin: 20px 0;
        }

        a {
            color: #3498db;
            text-decoration: none;
            font-weight: bold;
            margin: 0 15px;
        }

        a:hover {
            color: #258cd1;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<!-- Display current profile information -->
 <div class="profile-section">
        <h1>Broker Profile</h1>
        <?php
        // Display profile picture or default icon
        $profilePicture = !empty($brokerData['bPic']) ? $brokerData['bPic'] : 'images/default.png';
        echo '<img src="' . $profilePicture . '" alt="Profile Picture" class="profile-image">';
        ?>
        <p>Name: <?php echo $brokerData['bFirstName'] . ' ' . $brokerData['bLastName']; ?></p>
        <p>Username: <?php echo $brokerData['bUserName']; ?></p>
        <p>Email: <?php echo $brokerData['bEmail']; ?></p>
        <p>Mobile: <?php echo $brokerData['bMobileNumber']; ?></p>
    </div>

    <!-- Links for updating broker information and viewing listings -->
    <div class="links-section">
        <a href="profileupdate.php">Update Information</a>
        <a href="mylistings.php">View My Listings</a>
    </div>

    </body>
    </html>

    <?php
} else {
    echo "Broker not found";
}

mysqli_close($dbConnection);
?>
