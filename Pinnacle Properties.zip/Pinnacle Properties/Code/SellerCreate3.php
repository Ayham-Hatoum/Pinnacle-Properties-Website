<?php
session_start();
$propertyId = isset($_GET['pid']) ? $_GET['pid'] : '';

// Your database connection code here...
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the broker is logged in
if (!isset($_SESSION['broker_id'])) {
    header("Location: login.php");
    exit();
}

$bId = $_SESSION['broker_id'];

// Fetch pId from the database based on the provided property id
$fetchPIdQuery = "SELECT pId FROM property WHERE pId = '$propertyId'";
$result = mysqli_query($dbConnection, $fetchPIdQuery);

if ($result && $row = mysqli_fetch_assoc($result)) {
    $pId = $row['pId'];
} else {
    // Handle the case where property ID is not found
    echo 'Property ID not found';
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract seller details
    $sFirstName = mysqli_real_escape_string($dbConnection, $_POST['sFirstName']);
    $sLastName = mysqli_real_escape_string($dbConnection, $_POST['sLastName']);
    $sEmail = mysqli_real_escape_string($dbConnection, $_POST['sEmail']);
    $sMobileNumber = mysqli_real_escape_string($dbConnection, $_POST['sMobileNumber']);
    $sDoB = $_POST['sDoB']; // Capture the date of birth from the form

    // Use prepared statement to prevent SQL injection
    $insertSellerQuery = "INSERT INTO seller (bId, sFirstName, sLastName, sEmail, sMobileNumber, sDoB) 
                          VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($dbConnection, $insertSellerQuery);

    // Bind parameters to the prepared statement
    mysqli_stmt_bind_param($stmt, "ssssss", $bId, $sFirstName, $sLastName, $sEmail, $sMobileNumber, $sDoB);

    if (mysqli_stmt_execute($stmt)) {
        echo '<script>';
        echo 'alert("Seller created successfully");';
        echo 'window.location.href = "propertyedit.php?id=' . $pId . '";';
        echo '</script>';
        exit();
    } else {
        echo '<script>alert("Error creating seller");</script>';
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($dbConnection);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Seller</title>
    <style>
       body {
            font-family: 'Verdana', sans-serif;
            background-color: #f5f5f5;
            margin-left: 350px;
            margin-top:-10px;
            align-items: center;
            justify-content: center;
            height: 100vh;
            
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 5px 0px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-in-out;
        }

        form {
            display: grid;
            gap: 10px;
            animation: fadeInUp 1s ease-in-out;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="date"],
        textarea,
        select,
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s ease-in-out;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        textarea:focus,
        select:focus,
        input[type="file"]:focus {
            border-color: #4CAF50;
        }

     
        
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin-top: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease-in-out;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        select {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s ease-in-out;
        }

        select:focus {
            border-color: #4CAF50;
        }

        a {
            color: #4CAF50;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- The form for seller creation -->
    <div class="container">
        <h2>Create Seller</h2>

<form action="sellercreate3.php?pid=<?php echo htmlspecialchars($propertyId); ?>" method="post">
<input type="hidden" name="propertyId" value="<?php echo htmlspecialchars($propertyId); ?>">

            <label for="sFirstName">First Name:</label>
            <input type="text" id="sFirstName" name="sFirstName" required>

            <label for="sLastName">Last Name:</label>
            <input type="text" id="sLastName" name="sLastName" required>

            <label for="sEmail">Email:</label>
            <input type="email" id="sEmail" name="sEmail" required>

            <label for="sMobileNumber">Mobile Number:</label>
            <input type="tel" id="sMobileNumber" name="sMobileNumber" required>

            <label for="sDoB">Date of Birth:</label>
            <input type="date" id="sDoB" name="sDoB" required>

            <input type="submit" value="Create Seller">
        </form>
    </div>
</body>
</html>
