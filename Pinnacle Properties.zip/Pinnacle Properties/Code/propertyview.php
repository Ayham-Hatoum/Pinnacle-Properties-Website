<?php
include 'header.php';

// Sample database connection
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if property ID is provided in the URL
if (isset($_GET['id'])) {
    $propertyId = $_GET['id'];

    // Use prepared statement to avoid SQL injection
     $propertyDetailsQuery = "SELECT 
                                p.pType, p.pDesc, p.pArea, p.pPrice, p.pFeatured, p.pGovernate, p.pLocation, p.pName, p.oDate, p.pImage, p.bId,p.pId,
                                b.bFirstName, b.bLastName, b.bEmail AS brokerEmail, b.bMobileNumber AS brokerMobile,
                                s.sFirstName, s.sLastName, s.sEmail AS sellerEmail, s.sMobileNumber AS sellerMobile
                             FROM property p
                             JOIN broker b ON p.bId = b.bId
                             LEFT JOIN own o ON p.pId = o.pId
                             LEFT JOIN seller s ON o.sId = s.sId
                             WHERE p.pId = ?";
    
    $stmt = mysqli_prepare($dbConnection, $propertyDetailsQuery);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, "i", $propertyId);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Get result
    $propertyDetailsResult = mysqli_stmt_get_result($stmt);

    if ($propertyDetailsResult) {
        if (mysqli_num_rows($propertyDetailsResult) > 0) {
            $property = mysqli_fetch_assoc($propertyDetailsResult);

            // Display property details with styles and animation
            echo '<div class="container2">';
            echo '<h2>Property Details</h2>';
            echo '<div class="property-card fade-in">';
            echo '<div class="property-image-container">';
            echo '<img src="' . $property['pImage'] . '" alt="Property Image" class="property-image">';
            echo '</div>';
            echo '<div class="property-details">';
            
            // Display Property Details
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Property Name:</span>';
            echo '<span class="detail-value">' . $property['pName'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Type:</span>';
            echo '<span class="detail-value">' . $property['pType'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Description:</span>';
            echo '<span class="detail-value">' . $property['pDesc'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Area:</span>';
            echo '<span class="detail-value">' . $property['pArea'] . ' m²</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Governate:</span>';
            echo '<span class="detail-value">' . $property['pGovernate'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Location:</span>';
            echo '<span class="detail-value">' . $property['pLocation'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Listing Date:</span>';
            echo '<span class="detail-value">' . $property['oDate'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Price:</span>';
            echo '<span class="detail-value">$' . $property['pPrice'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Featured:</span>';
            echo '<span class="detail-value">' . $property['pFeatured'] . '</span>';
            echo '</div>';

            // Display Broker Information
            echo '<div class="property-detail">';
            echo '<h3>Broker Information</h3>';
            echo '<span class="detail-label">Name:</span>';
            echo '<span class="detail-value">' . $property['bFirstName'] . ' ' . $property['bLastName'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Email:</span>';
            echo '<span class="detail-value">' . $property['brokerEmail'] . '</span>';
            echo '</div>';
            echo '<div class="property-detail">';
            echo '<span class="detail-label">Mobile Number:</span>';
            echo '<span class="detail-value">' . $property['brokerMobile'] . '</span>';
            echo '</div>';

            // Display Seller Information (if available)
            if ($property['sFirstName'] && $property['sLastName']) {
                echo '<div class="property-detail">';
                echo '<h3>Seller Information</h3>';
                echo '<span class="detail-label">Name:</span>';
                echo '<span class="detail-value">' . $property['sFirstName'] . ' ' . $property['sLastName'] . '</span>';
                echo '</div>';
                echo '<div class="property-detail">';
                echo '<span class="detail-label">Email:</span>';
                echo '<span class="detail-value">' . $property['sellerEmail'] . '</span>';
                echo '</div>';
                echo '<div class="property-detail">';
                echo '<span class="detail-label">Mobile Number:</span>';
                echo '<span class="detail-value">' . $property['sellerMobile'] . '</span>';
                echo '</div>';
            }

            // Display "Update Property" button only for the owner
            if ($_SESSION['broker_id'] == $property['bId']) {
                echo '<div class="property-detail">';
                echo '<a href="propertyedit.php?id=' . $property['pId'] . '" class="update-button">Update Property</a>';
                echo '</div>';
            }

            echo '</div>'; // Closing property-details
            echo '</div>'; // Closing property-card
            echo '</div>'; // Closing container2
        } else {
            echo '<p>Property not found.</p>';
        }
    } else {
        echo '<p>Error executing query: ' . mysqli_error($dbConnection) . '</p>';
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    echo '<p>Invalid property ID.</p>';
}

mysqli_close($dbConnection);
?>




<style>
  .update-button {
        display: inline-block;
        padding: 10px 20px;
        background-color: #4CAF50; /* Green */
        color: white;
        text-align: center;
        text-decoration: none;
        font-size: 16px;
        border-radius: 5px;
        transition: background-color 0.3s;
    }

    .update-button:hover {
        background-color: #45a049; /* Darker Green on hover */
        text-decoration: none; /* Remove underline on hover */
    }
    .container2 {
        text-align: center;
        margin: 20px;
						width : 20 px;

    }

    .property-card {
        display: flex;
        border: 1px solid #ddd;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        border-radius: 8px;
        margin: 20px;
        background-color: #fff;
				width : 20 px;

    }

    .property-image-container {
        flex: 1;
        overflow: hidden;
        position: relative;
    }

    .property-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
    }

    .property-details {
        flex: 1;
        padding: 20px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
		width : 50 px;
    }

    .property-detail {
        margin-bottom: 10px;
    }

    .detail-label {
        font-weight: bold;
        color: #555;
    }

    .detail-value {
        color: #333;
    }

    .fade-in {
        opacity: 0;
        animation: fadeIn ease-in-out 1s forwards;
    }

    @keyframes fadeIn {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
</style>

<?php include 'footer.php'; ?>