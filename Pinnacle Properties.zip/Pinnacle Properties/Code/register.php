<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="index.php">
        <img src="images/Real Estate.gif" alt="Logo" class="logo"></a></span>
    <h2>Signup</h2>
</div>
</div>
<!-- banner -->

<style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
			background-image: url('images/Real Estate Logo.jpg');
			background-repeat: no-repeat;
            background-size: cover;
            height: 100vh;
            margin: 0;
	        animation: backgroundAnimation 5s linear infinite;

        }
  @keyframes backgroundAnimation {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.1);
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .logo {
            max-width: 150px;
            margin: 20px auto;
            display: block;
        }
    </style>
 <div class="container">
	 
		</a>
        <form action="Signup.php" method="post">
            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required><br><br>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required><br><br>

            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br><br>

            <label for="mobile">Mobile Number:</label>
            <input type="text" id="mobile" name="mobile" required><br><br>

            <input type="submit" value="Sign Up">
        </form>
		  <p style="text-align: center; margin-top: 20px;">
        Already signed up? <a href="login.php" style="color: #3498db; text-decoration: none; font-weight: bold;">Login here</a>.
    </p>
    </div>
	<script>
    function validatePhoneNumber() {
        var phoneNumber = document.getElementById("mobile").value;

        if (phoneNumber.length !== 8 || isNaN(phoneNumber)) {
            alert("Please enter a valid 8-digit phone number.");
            return false;
        }

        return true;
    }
</script>

