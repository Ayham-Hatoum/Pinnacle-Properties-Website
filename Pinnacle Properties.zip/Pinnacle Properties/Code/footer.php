<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-3">
                <h4>Information</h4>
                <ul class="row">
				<li class="col-lg-12 col-sm-12 col-xs-3"><a href="index.php">Home</a></li>
                    <li class="col-lg-12 col-sm-12 col-xs-3"><a href="about.php">About</a></li>
                    <li class="col-lg-12 col-sm-12 col-xs-3"><a href="contact.php">Support</a></li>
                </ul>
            </div>
            
            <div class="col-lg-3 col-sm-3">
                <h4>Follow us</h4>
                <a href="https://x.com/HatoumAyha52485?t=q4-1Ht6ByT_qGIUTalvAiw&s=09" target="_blank"><img src="images/twitter.png" alt="twitter"></a>
                <a href="https://www.facebook.com/profile.php?id=100012270739017&mibextid=ZbWKwL" target="_blank"><img src="images/facebook.png" alt="facebook"></a>
                <!-- Add links for other social media platforms if needed -->
				 <a href="https://www.instagram.com/ayham_hatoum?igsh=MW91OGR0ZXF0cXlkbg==" target="_blank"><img src="images/instagram.png" alt="instagram"></a>
				  <a href="https://www.linkedin.com/in/ayham-hatoum-4b7374218?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3B5RNOy4ZgSbedSsidc9LOmg%3D%3D" target="_blank"><img src="images/linkedin.png" alt="linkedin"></a>
            </div>

            <div class="col-lg-3 col-sm-3">
                <h4>Support</h4>
                <p><b>Ayham Hatoum</b><br>
                    <span class="glyphicon glyphicon-envelope"></span> <a href="mailto:ayhamhatoum8@gmail.com">ayhamhatoum8@gmail.com</a>
					<br> 
                    <span class="glyphicon glyphicon-earphone"></span> <a href="https://wa.me/96181331261" target="_blank">(+961) 81331261</a> (WhatsApp)
					</br>
            </div>
        </div>
        <p class="copyright">Copyright 2024 of Ayham Hatoum. All rights reserved.</p>
    </div>
</div>
