<?php
include 'header.php';

if (!isset($_SESSION['broker_id'])) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Your database connection code here...
$dbConnection = mysqli_connect("localhost", "root", "", "realestate");

if (!$dbConnection) {
    die("Connection failed: " . mysqli_connect_error());
}

$brokerId = $_SESSION['broker_id'];

// Fetch broker information
$sql = "SELECT * FROM broker WHERE bId = $brokerId";
$result = mysqli_query($dbConnection, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $brokerData = mysqli_fetch_assoc($result);
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Broker Information</title>
    <style>
	 .profile-image {
                width: 100px; /* Adjust the width as needed */
                height: 100px; /* Adjust the height as needed */
                border-radius: 50%;
                object-fit: cover;
                margin-right: 20px;

            }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: left;
            min-height: 50vh;
            overflow: auto;
            animation: fadeIn 1s ease-out;
        }

        h1 {
            color: #4caf50;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2em;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
						display : left;

        }

        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.8s forwards;
            width: 55%;
            text-align: left;
            margin: 20px 0;
			display : left;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
            font-size: 16px;
            font-weight: bold;
        }

        input {
            width: calc(100% - 16px);
            padding: 12px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<!-- Form for updating broker information -->
  <!-- Form for updating broker information and profile picture -->
    <div class="form-section">
        <h1>Update Broker Information</h1>
        <form method="post" action="" enctype="multipart/form-data">
            <label for="new_first_name">First Name:</label>
            <input type="text" name="new_first_name" value="<?php echo $brokerData['bFirstName']; ?>" required>
            <label for="new_last_name">Last Name:</label>
            <input type="text" name="new_last_name" value="<?php echo $brokerData['bLastName']; ?>" required>
            <label for="new_user_name">Username:</label>
            <input type="text" name="new_user_name" value="<?php echo $brokerData['bUserName']; ?>" required>
            <label for="new_email">Email:</label>
            <input type="email" name="new_email" value="<?php echo $brokerData['bEmail']; ?>" required>
            <label for="new_mobile">Mobile:</label>
            <input type="tel" name="new_mobile" value="<?php echo $brokerData['bMobileNumber']; ?>" required>
            <label for="new_profile_pic">Profile Picture:</label>
            <input type="file" name="new_profile_pic">
            <?php
            // Display current profile picture
            $profilePicture = !empty($brokerData['bPic']) ? $brokerData['bPic'] : 'default_icon.png';
            echo '<img src="' . $profilePicture . '" alt="Profile Picture" class="profile-image">';
            ?>
            <input type="submit" name="update_info" value="Update Information">
        </form>
    </div>

    </body>
    </html>

    <?php
} else {
    echo "Broker not found";
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_info'])) {
    // Ensure form data is set and not empty
    if (isset($_POST['new_first_name']) && isset($_POST['new_last_name']) && isset($_POST['new_user_name']) && isset($_POST['new_email']) && isset($_POST['new_mobile'])) {
        // Sanitize user input to prevent SQL injection
        $newFirstName = mysqli_real_escape_string($dbConnection, $_POST['new_first_name']);
        $newLastName = mysqli_real_escape_string($dbConnection, $_POST['new_last_name']);
        $newUserName = mysqli_real_escape_string($dbConnection, $_POST['new_user_name']);
        $newEmail = mysqli_real_escape_string($dbConnection, $_POST['new_email']);
        $newMobile = mysqli_real_escape_string($dbConnection, $_POST['new_mobile']);

        // Update broker information in the database
        $sqlUpdate = "UPDATE broker SET bFirstName = '$newFirstName', bLastName = '$newLastName', bUserName = '$newUserName', bEmail = '$newEmail', bMobileNumber = '$newMobile' WHERE bId = $brokerId";

        if (mysqli_query($dbConnection, $sqlUpdate)) {
            // Handle profile picture upload if a new file is uploaded
            if (!empty($_FILES["new_profile_pic"]["name"])) {
                $targetDir = "ProfilePic/" . $brokerId . "/";
                $targetFile = $targetDir . basename($_FILES["new_profile_pic"]["name"]);
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

                // Check if image file is a actual image or fake image
                $check = getimagesize($_FILES["new_profile_pic"]["tmp_name"]);
                if ($check !== false) {
                    $uploadOk = 1;
                } else {
                    echo '<script>alert("File is not an image.");</script>';
                    $uploadOk = 0;
                }

                // Check file size
                if ($_FILES["new_profile_pic"]["size"] > 500000) {
                    echo '<script>alert("Sorry, your file is too large.");</script>';
                    $uploadOk = 0;
                }

                // Allow certain file formats
                if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                    echo '<script>alert("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");</script>';
                    $uploadOk = 0;
                }

                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    echo '<script>alert("Sorry, your file was not uploaded.");</script>';
                } else {
                    // Create the directory if it doesn't exist
                    if (!is_dir($targetDir)) {
                        mkdir($targetDir, 0777, true);
                    }

                    // Upload the file
                    if (move_uploaded_file($_FILES["new_profile_pic"]["tmp_name"], $targetFile)) {
                        echo '<script>alert("The file ' . htmlspecialchars(basename($_FILES["new_profile_pic"]["name"])) . ' has been uploaded.");</script>';
                        $newProfilePic = $targetFile;
                        // Update the database with the new profile picture path
                        $sqlUpdatePic = "UPDATE broker SET bPic = '$newProfilePic' WHERE bId = $brokerId";
                        mysqli_query($dbConnection, $sqlUpdatePic);
                    } else {
                        echo '<script>alert("Sorry, there was an error uploading your file.");</script>';
                    }
                }
            } else {
                echo '<script>alert("Broker information updated successfully.");</script>';
            }
        } else {
            echo '<script>alert("Error updating broker information: ' . mysqli_error($dbConnection) . '");</script>';
        }
    } else {
        echo '<script>alert("All fields are required.");</script>';
    }
}

mysqli_close($dbConnection);
?>
